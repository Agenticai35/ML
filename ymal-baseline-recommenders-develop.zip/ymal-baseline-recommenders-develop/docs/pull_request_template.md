## Problem Statement
<!--- Describe the problem -->
<br/>

## Solution 
<!--- Describe the solution-->
<br/>

___
### :point_right: Type of Change
- [ ] Non-breaking bug fix 
- [ ] Non-breaking new feature
- [ ] Breaking change bug fix 
- [ ] Breaking change feature
- [ ] Documentation or Code sync 


###  :memo: Checklist
- [ ] Relevant docs added to docs directory and pushed to github pages
- [ ] Has code been formatted with Black
- [ ] Is DRY principle being followed
- [ ] Is snake case being used for naming packages, modules, functions and variables
- [ ] Is kebab case being used for repo name
- [ ] Are all parameters and variables appropriately typed
- [ ] Is dynaconf being used for configuration management
- [ ] Are all the parameters and variables appropriately typed
- [ ] Is poetry being used for dependency management 
- [ ] Have unit and functional tests created/updated and executed
- [ ] Are appropriate levels of logging being used
- [ ] Code Coverage ___
