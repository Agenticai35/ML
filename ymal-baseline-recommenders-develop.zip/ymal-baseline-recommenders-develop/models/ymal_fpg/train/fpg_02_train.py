# Databricks notebook source
# MAGIC %md
# MAGIC # Notebook Summary
# MAGIC
# MAGIC 1. Install required packages & notebook scoped parameters
# MAGIC 2. Define query params
# MAGIC 3. Train model and log it with MLFlow

# COMMAND ----------

# MAGIC %md
# MAGIC ## Installs & Params

# COMMAND ----------

dbutils.widgets.text("settings_path", defaultValue="/Workspace/Repos/shared/ymal-baseline-recommenders/settings.toml")

# COMMAND ----------

import mlflow
from pyspark.ml.fpm import FPGrowth, FPGrowthModel
from pyspark.sql import functions as F, types as T, Window
from pyspark.ml import Model

import calendar, datetime as dt, os, pytz, re, time
from dynaconf import Dynaconf

# COMMAND ----------

settings_path = dbutils.widgets.get("settings_path")

# Create a Dynaconf instance
settings = Dynaconf(settings_files=[settings_path], environments=True)

# COMMAND ----------

# run the notebook only on the weekdays specified for model train/inf/load in settings toml

# set first weekday to Monday to align with datetime module
calendar.setfirstweekday(calendar.MONDAY)
# Weekdays on which Train Inference Load notebooks are run
til_run_weekdays = settings.ymal_fpg.fpg_train_inf_load_weekdays

# convert string from settings file to list of ints (for if statement) and weekday names (for logging)
lst_til_weekday_ints = [int(x) for x in str.split(til_run_weekdays, ",")]
lst_til_weekday_names = [calendar.day_name[x] for x in lst_til_weekday_ints]


job_timezone = pytz.timezone(settings.ymal_fpg.fpg_workflow_timezone)
utc_datetime = dt.datetime.now().replace(tzinfo=pytz.timezone("UTC"))
local_datetime = utc_datetime.astimezone(job_timezone)

if local_datetime.weekday() in lst_til_weekday_ints:
    print("Continue running notebook since train inference load should run today.")
else:
    exit_msg = f"Today is {calendar.day_name[local_datetime.weekday()]}.\n\tFPG 02 Train notebook runs on: {lst_til_weekday_names}"
    dbutils.notebook.exit(exit_msg)

# COMMAND ----------

spark.catalog.setCurrentDatabase(settings.ymal_schema)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Query Params

# COMMAND ----------

# Set lookback date range from which to extract observed baskets
current_date = dt.date.today()
endDate = current_date - dt.timedelta(days=settings.ymal_fpg.fpg_precomp_lag_days)
startDate = endDate - dt.timedelta(days=settings.ymal_fpg.fpg_precomp_days_range - 1)

print("T360 actuals date range: {0} -> {1}".format(startDate, endDate))

fltr_busDate = F.col("BusinessDate").between(startDate, endDate)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Train and Log Model

# COMMAND ----------

# mlflow.set_experiment(settings.ymal_fpg.fpg_experiment_name)

artifacts_location = f"dbfs:{settings.ymal_fpg.FPG_ARTIFACTS_LOCATION}" 
experiments_path = settings.ymal_fpg.FPG_EXPERIMENT_PATH 
# name="testfpmodelname1"
fpg_registered_model_name = settings.ymal_fpg.fpg_registered_model_name
artifact_path = settings.ymal_fpg.FPG_ARTIFACT_PATH
experiment_name = f"{experiments_path}/{fpg_registered_model_name}"

if mlflow.get_experiment_by_name(experiment_name) is None:
    print(f"Experiment with name `{experiment_name}` doesn't exists!")
    experiment_id = mlflow.create_experiment(name=f"{experiment_name}",
                                    artifact_location=artifacts_location)
else:
    print(f"Experiment with name `{experiment_name}` exists!")
    experiment_id = mlflow.get_experiment_by_name(experiment_name).experiment_id

print(f"artifacts_location : {artifacts_location}")
print(f"experiments_path : {experiments_path}")
print(f"fpg_registered_model_name : {fpg_registered_model_name}")
print(f"artifact_path : {artifact_path}")
print(f"experiment_name : {experiment_name}")
print(f"experiment_id : {experiment_id}")


with mlflow.start_run(experiment_id=experiment_id):
    # define input dataset and model
    fpg_input_df = spark.table(settings.ymal_fpg.fpg_input_table_name).filter(fltr_busDate)

    fpg = FPGrowth(
        minSupport=settings.ymal_fpg.fpg_min_support,
        minConfidence=settings.ymal_fpg.fpg_min_conf,
        itemsCol=f"{settings.ymal_fpg.fpg_eph_level}_set",
    )
    print("Loading input dataset and initializing model complete")

    # log parameters and input dataset to MLflow
    mlflow.log_param("minSupport", settings.ymal_fpg.fpg_min_support)
    mlflow.log_param("minConfidence", settings.ymal_fpg.fpg_min_conf)
    mlflow.log_param("itemsCol", f"{settings.ymal_fpg.fpg_eph_level}_set")

    fpg_input_mlflow_data = mlflow.data.from_spark(
        df=fpg_input_df, table_name=settings.ymal_fpg.fpg_input_table_name
    )

    mlflow.log_input(dataset=fpg_input_mlflow_data, context="training")
    print("Param and input data logging configured")

    # log model to MLflow
    print("Model logging beginning")
    mlflow.spark.log_model(
        artifact_path=artifact_path,
        spark_model=fpg.fit(fpg_input_df),
        registered_model_name=fpg_registered_model_name
    )
    print("Model logging completed")
