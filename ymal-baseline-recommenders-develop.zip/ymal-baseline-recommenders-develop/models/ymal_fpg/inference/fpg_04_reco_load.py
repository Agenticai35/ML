# Databricks notebook source

# MAGIC %md
# MAGIC ###Import

# COMMAND ----------

#Import
from pyspark.sql.functions import col, to_timestamp, lit, when
from pyspark.sql import functions as F 
from pyspark.sql.types import StringType, StructType, StructField, ArrayType

import ast, glob, os, sys
import configparser
import calendar, datetime as dt, pytz
from datetime import datetime, timedelta
from pathlib import PurePath

from dynaconf import Dynaconf

# COMMAND ----------

settings_path = dbutils.widgets.get("settings_path")

# Create a Dynaconf instance
settings = Dynaconf(settings_files=[settings_path], environments=True)

# COMMAND ----------

# run the notebook only on the weekdays specified for model train/inf/load in settings toml

# set first weekday to Monday to align with datetime module
calendar.setfirstweekday(calendar.MONDAY)
# Weekdays on which Train Inference Load notebooks are run
til_run_weekdays = settings.ymal_fpg.fpg_train_inf_load_weekdays

# convert string from settings file to list of ints (for if statement) and weekday names (for logging)
lst_til_weekday_ints = [int(x) for x in str.split(til_run_weekdays, ",")]
lst_til_weekday_names = [calendar.day_name[x] for x in lst_til_weekday_ints]


job_timezone = pytz.timezone(settings.ymal_fpg.fpg_workflow_timezone)
utc_datetime = dt.datetime.now().replace(tzinfo=pytz.timezone("UTC"))
local_datetime = utc_datetime.astimezone(job_timezone)

if local_datetime.weekday() in lst_til_weekday_ints:
    print("Continue running notebook since train inference load should run today.")
else:
    exit_msg = f"Today is {calendar.day_name[local_datetime.weekday()]}.\n\tFPG 02 Train notebook runs on: {lst_til_weekday_names}"
    dbutils.notebook.exit(exit_msg)

# COMMAND ----------

"""
SOURCE date_string FROM SETTINGS IN SAME WAY IT'S SOURCED FOR OFFLINE INFERENCE NOTEBOOK
# Widget to get the run_date
# dbutils.widgets.text("run_date", "", "Run Date (yyyy-mm-dd)")
# date_string = dbutils.widgets.get("run_date")
"""
date_string = (
    dt.date.today() - dt.timedelta(days=settings.ymal_fpg.fpg_precomp_lag_days)
).strftime("%Y-%m-%d")

# # Widget to get the keyvault

# COMMAND ----------

# MAGIC %md
# MAGIC ####PostgreSQL

# COMMAND ----------

import json
import psycopg2
from edap_keyvault.key_vault import KeyVault
from edap_repo.factory.repo_factory import RepoFactory, RepoType
from edap_repo.postgresql.dal import CursorOperations
from pyspark.sql.functions import col, lit, to_json, struct, substring

# COMMAND ----------

keyvault_util = KeyVault(dbutils=dbutils)

cosmos_postgres_connection_key = (
    settings.ymal_fpg.FPG_POSTGRES_CONNECTION_SECRET
)

postgres_connection_dict = json.loads(
    keyvault_util.get_secret(cosmos_postgres_connection_key)
)

config = {"connection_parameters": postgres_connection_dict}
factory = RepoFactory()
repo_handler = factory.create(RepoType.COSMOS_PGSQL, **config)
py_connection_string = (
    repo_handler.postgresql_session.connection_parameters.py_connection_string
)

# Establish the connection
connection = psycopg2.connect(
    host=postgres_connection_dict["host"],
    database=postgres_connection_dict["db"],
    user=postgres_connection_dict["user"],
    password=postgres_connection_dict["password"],
    port=postgres_connection_dict["port"],
)

# COMMAND ----------

# MAGIC %md
# MAGIC ####Create run_id for partition

# COMMAND ----------

# Create a cursor object
cursor = connection.cursor()

# Execute SQL query to get the next sequence value
cursor.execute("SELECT nextval('ymal.run_id_seq')")

# Fetch the sequence value
p_run_id = cursor.fetchone()[0]

# Print the retrieved sequence value
print("The next run_id is:", p_run_id)

# Close the cursor and connection
cursor.close()
connection.close()

# COMMAND ----------

# MAGIC %md
# MAGIC ####Drop partition if exist -need for rerun

# COMMAND ----------

# dropping the partition
drop_partition_sql = f"DROP TABLE IF EXISTS ymal.fpg_reco_run_{p_run_id}"

repo_handler.execute(drop_partition_sql)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Partition table and index creation

# COMMAND ----------

# Partion dynamic run_id
create_partition_sql = f"""
CREATE TABLE ymal.fpg_reco_run_{p_run_id} PARTITION OF ymal.fpg_reco FOR VALUES IN ({p_run_id})
"""
create_index_sql = f"""
CREATE INDEX idx_bskt_sortedStr_mapn_run_{p_run_id} ON ymal.fpg_reco_run_{p_run_id} (bskt_sortedStr_mapn)
"""
repo_handler.execute(create_partition_sql)
repo_handler.execute(create_index_sql)

# COMMAND ----------

# Define your query and run_date
table_name = f"{settings.ymal_schema}.{settings.ymal_fpg.fpg_reco_snapshots_table_name}"
p_run_date = date_string  # run_date from widget

# Query to select data from the source table
query = f"""
SELECT bskt_sortedStr_mapn, reco_ranked_list as reco_ranked_list_array FROM {table_name}
WHERE TrainingDate = '{p_run_date}'
"""

# Load the query results into a DataFrame
df = spark.sql(query)

df = df.withColumn(
    "reco_ranked_list", substring(col("reco_ranked_list_array").cast("string"), 1, 4000)
)


# Drop the original reco_ranked_list if not needed anymore
df = df.drop("reco_ranked_list_array")

# Add run_id column
df = df.withColumn("run_id", lit(p_run_id))

total_records = df.count()
print(f"total_records: {total_records}")
# COMMAND ----------

# CODE THAT USES OLD AUTH PATTERN, WHICH IS NOT RELEVANT AS OF THIS COMMIT FROM 2024-12-11: 580f4fad4c0f0219f515f73a661a634cb0812514
# # Avoid any timeouts
# pg_connection_pwd = str(keyvault_util.get_secret(keyvault_string))
# postgres_connection_dict = {
#     "host": host_string,
#     "db": db_string,
#     "user": user_string,
#     "password": pg_connection_pwd,
#     "port": port_string,
# }

# Avoid any timeouts
# pg_connection_pwd = str(
# keyvault_util.get_secret("s00188deveus2cpgairms-fpg-AdminPassword")
# )
# postgres_connection_dict = {"host":"c-s00188deveus2cpgairms-fpg.ra2ep4wah4vuzs.postgres.cosmos.azure.com" , "db":"DataCatalog" , #"user":"citus", "password":pg_connection_pwd, "port":5432}

# COMMAND ----------

# Build the JDBC URL
jdbc_url = f"jdbc:postgresql://{postgres_connection_dict['host']}:{postgres_connection_dict['port']}/{postgres_connection_dict['db']}"

# Connection properties
connection_properties = {
    "user": postgres_connection_dict["user"],
    "password": postgres_connection_dict["password"],
    "driver": "org.postgresql.Driver",
}

# Step 3: Write the DataFrame to PostgreSQL
df.write.jdbc(
    url=jdbc_url, table=settings.ymal_fpg.FPG_RECOS_TABLE_NAME, mode="append", properties=connection_properties
)

# COMMAND ----------

# MAGIC %md
# MAGIC ####Dropping the pervious partition for better indexing and to stage only the latestest training data

# COMMAND ----------

# dropping the partition
if total_records > 0:
    drop_partition_sql = f"DROP TABLE IF EXISTS ymal.fpg_reco_run_{p_run_id - 1}"
    repo_handler.execute(drop_partition_sql)
