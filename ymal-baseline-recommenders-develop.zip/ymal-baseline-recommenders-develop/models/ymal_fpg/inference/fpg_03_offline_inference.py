# Databricks notebook source
# MAGIC %md
# MAGIC # Notebook Summary
# MAGIC -----
# MAGIC ### Pre-compute recos for all observed baskets based on Association Rules from YMAL-Frequent Pattern Growth (FPG) Variant
# MAGIC -----
# MAGIC -----
# MAGIC ##### Cluster setup
# MAGIC - DBR 14.3 LTS ML (mlflow is a preinstalled library for this DB Runtime)
# MAGIC - Additional libraries installed on cluster which aren't included in the DB Runtime: 
# MAGIC     - dynaconf==3.2.0
# MAGIC     - azure=4.0.0
# MAGIC
# MAGIC ##### Read in data sources
# MAGIC - Take trailing N days of observed baskets, select NotionalProductID_set, sort that column then take distinct values
# MAGIC   - differing orders of the same items makes for distinct sets so that's why the sort is required (otherwise a bagel & latte would be distinct from a latte & bagel)
# MAGIC - Load latest trained model and return the AssociationRules DF from it
# MAGIC
# MAGIC
# MAGIC ##### Precompute Recos: Join Observed Baskets Into Assoc Rules
# MAGIC - Join Observed Baskets into Assoc Rules, 2 columns:
# MAGIC     - Basket of Items (NotionalProductId)
# MAGIC     - Recommended Items (NotionalProductId)
# MAGIC
# MAGIC ##### Express baskets in terms of MAPNs so it's easier to join payload into this table
# MAGIC - use PD to EPH conversion logic to add columns which just re-express existing EPH columns in terms of PD
# MAGIC     - Basket Of Items MAPN (MenuAcmeProductNumber)
# MAGIC     - Recommended Items (MenuAcmeProductNumber)
# MAGIC
# MAGIC
# MAGIC ##### Write output
# MAGIC - Should the output table have a couple columns to track params like observed basket lookback and assoc rules training date?
# MAGIC   - If so the output could be appended and we could delete rows where assoc rule training date is beyond some lookback window (I'd propose that lookback be 52 weeks so we can do YoY calculations as needed)
# MAGIC   - From that table we could always take the latest precomputed recos and write them to a table with "_current" suffix so DeepBrew doesn't have to filter the accumulating snapshots table, they can just select * from the "_current" table

# COMMAND ----------

# MAGIC %md
# MAGIC ## Installs and params

# COMMAND ----------

dbutils.widgets.text(
    "settings_path",
    defaultValue="/Workspace/Repos/shared/ymal-baseline-recommenders/settings.toml",
)

# COMMAND ----------

import mlflow
from pyspark.ml.fpm import FPGrowthModel
from pyspark.sql import functions as F, types as T, Window

import calendar, datetime as dt, math, numpy as np, os, pytz, re, time
from itertools import chain, combinations

from dynaconf import Dynaconf

# COMMAND ----------

settings_path = dbutils.widgets.get("settings_path")

# Create a Dynaconf instance
settings = Dynaconf(settings_files=[settings_path], environments=True)

# COMMAND ----------

# run the notebook only on the weekdays specified for model train/inf/load in settings toml

# set first weekday to Monday to align with datetime module
calendar.setfirstweekday(calendar.MONDAY)
# Weekdays on which Train Inference Load notebooks are run
train_inf_load_weekdays = settings.ymal_fpg.fpg_train_inf_load_weekdays

# convert string from settings file to list of ints (for if statement) and weekday names (for logging)
train_inf_load_weekday_ints = [int(x) for x in str.split(train_inf_load_weekdays, ",")]
train_inf_load_weekday_names = [calendar.day_name[x] for x in train_inf_load_weekday_ints]


job_timezone = pytz.timezone(settings.ymal_fpg.fpg_workflow_timezone)
utc_datetime = dt.datetime.now().replace(tzinfo=pytz.timezone("UTC"))
local_datetime = utc_datetime.astimezone(job_timezone)

if local_datetime.weekday() in train_inf_load_weekday_ints:
    print("Continue running notebook since train inference load should run today.")
else:
    exit_msg = f"Today is {calendar.day_name[local_datetime.weekday()]}.\n\tFPG 02 Train notebook runs on: {train_inf_load_weekday_names}"
    dbutils.notebook.exit(exit_msg)

# COMMAND ----------

spark.catalog.setCurrentDatabase(settings.ymal_schema)

# COMMAND ----------

# Set lookback date range from which to extract observed baskets
current_date = dt.date.today()
endDate = current_date - dt.timedelta(days=settings.ymal_fpg.fpg_precomp_lag_days)
startDate = endDate - dt.timedelta(days=settings.ymal_fpg.fpg_precomp_days_range - 1)

replaceWhere_trainDate_expr = f"TrainingDate = '{endDate}'"

print("T360 actuals date range: {0} -> {1}".format(startDate, endDate))

# COMMAND ----------

print(replaceWhere_trainDate_expr)

# COMMAND ----------

# cluster setup
max_workers = 4
cores_per_worker = 4
max_cores = max_workers * cores_per_worker

# processing reqs (ptns per day will depend on worker core size, 16 was chosen for Standard_DS3_v2 workers)
days_in_range = int((endDate - startDate).days + 1)
partitions_per_day = 16
total_partitions_required = days_in_range * partitions_per_day

# update spark sql shuffle partitions if needed
curr_ptns = int(spark.conf.get("spark.sql.shuffle.partitions"))
if total_partitions_required > curr_ptns:
    print(f"Need more Partitions!! Have {curr_ptns}, need at least {total_partitions_required}")
    shuffle_partition_factor = math.ceil(total_partitions_required / max_cores)
    new_shuffle_partitions = max_cores * shuffle_partition_factor
    spark.conf.set("spark.sql.shuffle.partitions", new_shuffle_partitions)
    print(
        f"Shuffle partitions set to: {spark.conf.get('spark.sql.shuffle.partitions')}"
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ### Funcs

# COMMAND ----------

def _get_model_versions(registeredModelName):
    """
    Returns model versions list of tuples for a given model name
    This function meant to return all model versions
      inputs:
        registeredModelName: Name of a model registered in MLFlow
      outputs:
        list_model: List of tuples of (model version, model run_id)
    """
    # initialize an MlflowClient so function caller doesn't need to provide that
    mlfc = mlflow.MlflowClient()
    # identify the model's latest version
    model_versions = []
    for mv in mlfc.search_model_versions(f"name='{registeredModelName}'"):
        model_versions.append(int(mv.version))
    return model_versions


def load_latest_model(registeredModelName):
    """
    Uses output of model_versions() to load latest model
    inputs:
      registeredModelName: Name of a model registered in MLFlow
    outputs:
      loaded_model.stages[0]: The first object in
    """
    # initialize an MlflowClient so function caller doesn't need to provide that
    mlfc = mlflow.MlflowClient()

    # extract latest runId from model versions list of tuples
    latest_model_vers = _get_model_versions(registeredModelName)[0]
    print(f"latest_model_version={latest_model_vers}")
    latest_model_path = mlfc.get_model_version_download_uri(
        registeredModelName, latest_model_vers
    )
    model_object = mlflow.spark.load_model(latest_model_path).stages[0]
    return model_object

# COMMAND ----------

# MAGIC %md
# MAGIC ### Query Params

# COMMAND ----------

# EPH level at which to train the FPGrowth Model
fpg_eph_level = settings.ymal_fpg.fpg_eph_level

# PRODUCT DETAIL TABLE FILTERS
allProduct_sizeCode_col = 'sizeCode'
cond_mapn_notNull = (F.col("MenuAcmeProductNumber").isNotNull())
cond_sizeCode_notNull = (F.col(allProduct_sizeCode_col).isNotNull())
# core product types
cond_core_prod_types = F.expr(f"ProductTypeName in ('At Home', 'Beverage', 'Food')")
# avocado spread modifier
cond_prod_type_mod = F.expr(f"ProductTypeName ='Modifier'")
cond_prod_name_avo_sprd = F.expr(
    f"ProductNameEnglishUS like '%Avocado%' AND MenuAcmeProductNumber == '2122257'"
)
cond_avocado_spread = cond_prod_type_mod & cond_prod_name_avo_sprd
# core product types and avocado spread
cond_prod_types = cond_core_prod_types | cond_avocado_spread

cond_prod_cntry_code = F.expr(f"ProductCountryCode = 'US'")
cond_active_item = F.expr(f"SellableItemSupplyItemActiveIndicator = 1")

# size code filters (if AtHome then 1 Bag, if Bev then Grande|Double, if Food then Serving)
cond_athm_size_code = F.expr(f"SellableItemAtHomeSizeCode = '1 Bag'")
cond_bvrg_size_code = F.expr(
    f"SellableItemBeverageServingSizeCode in ('Grande', 'Double')"
)
cond_food_size_code = F.expr(f"SellableItemFoodSizeCode = 'Serving'")
cond_size_codes = (
    cond_athm_size_code
    | cond_bvrg_size_code
    | cond_food_size_code
    |
    # exception to the pattern to include Avocado spread
    (cond_prod_name_avo_sprd & cond_food_size_code)
)

# ASSOC RULES FILTERS
# minimum lift required for Assoc Rules to be included in offline inferencing
cond_min_lift = F.expr(f"lift > {settings.ymal_fpg.fpg_min_lift}")


# ACTUALS FILTERS
fltr_observedBasket_dates = F.col("BusinessDate").between(startDate, endDate)

# COMMAND ----------

# WINDOW EXPRESSIONS

ptn_bskt = [settings.ymal_fpg.fpg_antes_only_bskt_col]
ptn_bskt_cons = [settings.ymal_fpg.fpg_antes_only_bskt_col, "consequent"]
ptn_bskt_mapn = [settings.ymal_fpg.fpg_antes_only_bskt_col, 'MenuAcmeProductNumber']

ord_mapnDesc = F.desc('MenuAcmeProductNumber')
ord_liftDesc = F.desc("lift")

# window partitioned by basket order by lift descending
wdw_bskt_lift = Window.partitionBy(*ptn_bskt).orderBy(ord_liftDesc)

# window over Basket order by MAPN descending
wdw_bskt_mapn = Window.partitionBy(*ptn_bskt).orderBy(ord_mapnDesc)

# window partitioned by basket & consequent order by lift descending
wdw_bsktCons_lift = Window.partitionBy(*ptn_bskt_cons).orderBy(ord_liftDesc)

# window partitioned by basket & consequent order by MAPN descending
wdw_bsktCons_mapn = Window.partitionBy(*ptn_bskt_cons).orderBy(ord_mapnDesc)

# window over basket & MAPN consequent order by lift descending
wdw_bsktMapn_lift = Window.partitionBy(*ptn_bskt_mapn).orderBy(ord_liftDesc)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Read in source data

# COMMAND ----------

# processing reqs for repartitioning obs_bskt DF (ptns per day will depend on worker core size, 64 was chosen for Standard_DS3_v2 workers)
partitions_per_day = 64
total_partitions_required = days_in_range * partitions_per_day

# update spark sql shuffle partitions if needed
curr_ptns = int(spark.conf.get("spark.sql.shuffle.partitions"))
if total_partitions_required > curr_ptns:
    print(f"Need more Partitions!! Have {curr_ptns}, need at least {total_partitions_required}")
    shuffle_partition_factor = math.ceil(total_partitions_required / max_cores)
    obs_bskts_ptns = max_cores * shuffle_partition_factor

obs_bskts_ptns

# COMMAND ----------

# select columns from EPH table
slct_eph = [
    "ProductTypeDescription",
    "NotionalProductDescription",
    fpg_eph_level,
    "ItemID",
]

# eph : Enterprise Product Hierarchy
eph = spark.table(settings.ymal_fpg.src_tbl_eph).select(slct_eph)

# COMMAND ----------

# select columns from Product Details table
slct_pd = [
    # Needed ID columns
    "MenuAcmeProductNumber",
    "SellableItemSupplyItemNumber",
    # filter cols
    "ProductCountryCode",
    "ProductTypeName",
    "ProductId",
    # product Name
    "ProductNameEnglishUS",
    # size codes
    "SellableItemAtHomeSizeCode",
    "SellableItemBeverageServingSizeCode",
    "SellableItemFoodSizeCode",
]
col_name_dict = {
    "ProductTypeName": "ProductTypeDescription",
    "SellableItemSupplyItemNumber": "ItemID",
    "ProductId": fpg_eph_level,
}

# prod_det : PRODuct DETail
prod_det = (
    spark.table(settings.ymal_fpg.src_tbl_prod_det)
    .filter(cond_prod_types & cond_prod_cntry_code & cond_active_item & cond_size_codes)
    .select(slct_pd)
    .withColumnsRenamed(col_name_dict)
    .withColumn(allProduct_sizeCode_col, F.coalesce(*slct_pd[-3:]))
    .drop(*slct_pd[-3:])
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### MAPN 1:1 with sizeCode and Name
# MAGIC - Need to get a single sizeCode and name associated with each MAPN
# MAGIC - This DF will be joined to consequents so that all required attributes are appended to recos when the EPH denominated recos are re-expressed in MAPN terms

# COMMAND ----------

# establish 1:1 mapping between MAPN and two attributes: sizeCode, ProductNameEnglishUS
prodName_col = 'mapn_names_set_size'
name_set_size_range = {"min": 1, "max": 1}
cond_two_names = F.col(prodName_col) == F.lit(2)
cond_cake_pop_two_names = (F.col("MenuAcmeProductNumber") == F.lit("2122932")) & (
    F.col("ProductNameEnglishUS") == F.lit("Vanilla Cake Pop")
)
whn_two_names = F.when(
    cond_two_names,
    F.when(cond_prod_name_avo_sprd, F.lit(1)).when(cond_cake_pop_two_names, F.lit(1))
).otherwise(F.col(prodName_col))
cond_single_name_mapns = (F.col(prodName_col) == F.lit(1))

# Product Details with Size code and cleaned product Name included
pd_size_name = (
    prod_det
    # remove null MAPNs, these rows can't be used anyways
    .filter(cond_mapn_notNull & cond_sizeCode_notNull)
    # retain only required columns and take distinct rows
    .select("MenuAcmeProductNumber", "sizeCode", "ProductNameEnglishUS")
    .distinct()
    # identify MAPNs with multiple distinct ProductNameEnglishUS values
    .withColumn(
        prodName_col,
        F.size(
            F.collect_set("ProductNameEnglishUS").over(
                Window.partitionBy("MenuAcmeProductNumber")
            )
        ),
    )
    # flag the handful of 2 Name MAPNs I know how to process and retain just those ones
    .withColumn(prodName_col, whn_two_names)
    .filter(cond_single_name_mapns)
    # drop the extra columns used to rationalize MAPN:Name down to 1:1 for all rows
    .drop(prodName_col)
)

# COMMAND ----------

# QA verifying relationships between MAPN to sizeCode &  MAPN to ProductNameEnglishUS is 1:1
    # PASS = (sizeCode|ProductNameEnglishUS)_set_size == 1 for all rows
grp = ["MenuAcmeProductNumber"]
agg = ["sizeCode", "ProductNameEnglishUS"]

display(
    pd_size_name.groupBy("MenuAcmeProductNumber")
    .agg(
        F.collect_set(agg[0]).alias(f"{agg[0]}_set"),
        F.collect_set(agg[1]).alias(f"{agg[1]}_set"),
    )
    .withColumn(f"{agg[0]}_set_size", F.size(f"{agg[0]}_set"))
    .withColumn(f"{agg[1]}_set_size", F.size(f"{agg[1]}_set"))
    .orderBy(F.desc(f"{agg[0]}_set_size"), F.desc(f"{agg[0]}_set_size"))
)

# COMMAND ----------

# ob_cnts : Observed Basket CouNTS
ob_cnts = (
    spark.table(settings.ymal_fpg.fpg_input_table_name)
    .filter(fltr_observedBasket_dates)
    # limit to MOP orders, since serving recos for MOP only
    .filter(F.expr(settings.ymal_fpg.fpg_chnl_fltr))
    .withColumn(f"{fpg_eph_level}_set", F.array_sort(f"{fpg_eph_level}_set"))
    .groupBy(f"{fpg_eph_level}_set")
    .agg(F.count("SalesTransactionId").alias("trans_cnt"))
)

# COMMAND ----------

# MONITOR: count of distinct baskets for which recos must be computed
ob_cnts.count()

# COMMAND ----------

# fpgm : Frequent Pattern Growth Model
fpgm = load_latest_model(settings.ymal_fpg.fpg_registered_model_name)

# COMMAND ----------

# ar : Association Rules
assoc_rules = fpgm.associationRules.filter(cond_min_lift).withColumn(
    "antecedent_concat", F.array_join(F.array_sort("antecedent"), "|")
)

# COMMAND ----------

(
    assoc_rules.write.format("delta")
    .mode("overwrite")
    .saveAsTable(settings.ymal_fpg.fpg_assoc_rules_table_name)
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Map Assoc Rule NPIs to MAPNs
# MAGIC - If an NPI isn't in an Antecedent of the Assoc Rules it can't be mapped to a consequent
# MAGIC - If an NPI can't be mapped to a consequent we don't have a reco for it; therefore, no need to map that NPI to a MAPN
# MAGIC - Let's only map NPIs to MAPNs for which we can provide recos and limit the scope of the problem to solve.

# COMMAND ----------

assoc_rules = spark.table(settings.ymal_fpg.fpg_assoc_rules_table_name)

# COMMAND ----------

assoc_rule_cols = ["antecedent", "consequent"]

# ara : Association Rule Antecednets
assoc_rule_antes = (
    assoc_rules.select(assoc_rule_cols[0])
    .withColumn(assoc_rule_cols[0], F.explode(assoc_rule_cols[0]))
    .withColumnRenamed(assoc_rule_cols[0], fpg_eph_level)
    .distinct()
)

# arc : Association Rule Consequents
assoc_rule_cons = (
    assoc_rules.select(assoc_rule_cols[1])
    .withColumn(assoc_rule_cols[1], F.explode(assoc_rule_cols[1]))
    .withColumnRenamed(assoc_rule_cols[1], fpg_eph_level)
    .distinct()
)

# COMMAND ----------

"""
Join Assoc Rule Antecedents and Consequents to Product Details on:
  - assoc_rules.NotionalProductId == PD.ProductId
  - assoc_rules.NotionalProductID == EPH.NotionalProductID -> EPH.ItemID == PD.SellableItemSupplyItemNumber
Union results
split into a DF with non-Null MAPNs and another DF with Null MAPNs
"""

# ANTECEDENTS
# arap : Assoc Rule Antecedents joined on EPH.NPI == PD.ProductId
assoc_rule_antes_prod = (
    assoc_rule_antes.join(prod_det, [fpg_eph_level], "left")
    .select("MenuAcmeProductNumber", fpg_eph_level, "ProductTypeDescription")
    .distinct()
)

# arai : Assoc Rule Antecedents joined on EPH.ItemID == PD.SellableItemSupplyItemNumber (aliased as ItemID)
assoc_rule_antes_item = (
    assoc_rule_antes.join(eph, [fpg_eph_level], "left")
    .join(
        prod_det.drop(fpg_eph_level, "ProductTypeDescription"),
        ["ItemID"],
        "left",
    )
    .select("MenuAcmeProductNumber", fpg_eph_level, "ProductTypeDescription")
    .distinct()
)

assoc_rule_antes_full = assoc_rule_antes_prod.unionAll(assoc_rule_antes_item).distinct()

# aram : Assoc Rule Antecedents Missing mapns
assoc_rule_antes_missingmapns = (
    assoc_rule_antes_full.filter(F.col("MenuAcmeProductNumber").isNull())
    .withColumn("AssocRuleType", F.lit("antecedent"))
    .withColumn("TrainingDate", F.lit(endDate))
)

# aran : Assoc Rule Antecedents Nonnull mapns
assoc_rule_antes_nonnullmapns = assoc_rule_antes_full.filter(F.col("MenuAcmeProductNumber").isNotNull())

# COMMAND ----------

# CONSEQUENTS
# arcp : Assoc Rule Consequents joined on EPH.NPI == PD.ProductId
assoc_rule_cons_prod = (
    assoc_rule_cons.join(prod_det, [fpg_eph_level], "left")
    .select("MenuAcmeProductNumber", fpg_eph_level, "ProductTypeDescription")
    .distinct()
)

# arci : Assoc Rule Consequents joined on EPH.ItemID == PD.SellableItemSupplyItemNumber (aliased as ItemID)
assoc_rule_cons_item = (
    assoc_rule_cons.join(eph, [fpg_eph_level], "left")
    .join(
        prod_det.drop(fpg_eph_level, "ProductTypeDescription"),
        ["ItemID"],
        "left",
    )
    .select("MenuAcmeProductNumber", fpg_eph_level, "ProductTypeDescription")
    .distinct()
)

assoc_rule_cons_full = assoc_rule_cons_prod.unionAll(assoc_rule_cons_item).distinct()

# arcm : Assoc Rule Consequents Missing mapns
assoc_rule_cons_missingmapns = (
    assoc_rule_cons_full.filter(F.col("MenuAcmeProductNumber").isNull())
    .withColumn("AssocRuleType", F.lit("consequent"))
    .withColumn("TrainingDate", F.lit(endDate))
)

# process prod_det into MAPN, sizeCode & name

# arcn : Assoc Rule Consequents Nonnull mapns
assoc_rule_cons_nonnullmapns = (
    assoc_rule_cons_full.filter(F.col("MenuAcmeProductNumber").isNotNull())
    # inner join because pd_size_name provides attributes which are required to provide recos, so if a MAPN doesn't have those attributes, it can't be recommended anyway
    .join(pd_size_name, ["MenuAcmeProductNumber"], "inner")
)

# COMMAND ----------

# arnm : Assoc Rules with No Mapns
assoc_rule_no_mapns = assoc_rule_antes_missingmapns.unionAll(assoc_rule_cons_missingmapns)

# write Antecedent and Consequent items which have no MAPNs
(
    assoc_rule_no_mapns.write.format("delta")
    .mode('overwrite')
    .option('replaceWhere', replaceWhere_trainDate_expr)
    .saveAsTable(settings.ymal_fpg.fpg_ante_cons_items_no_mapns_table_name)
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Precompute recos (EPH only)
# MAGIC - Output has 1 row per consequent, each observed basket will have as many rows as consequents, which allows the output to be joined into the PD->EPH mapping table on consequent = EPH.NotionalProductId. Then we'll keep the MAPN column and collapse the recos into a complex type (map or struct) of MAPNs ranked on lift
# MAGIC
# MAGIC _________
# MAGIC __Summary of ETL steps__
# MAGIC 1. identify Max antecedent size
# MAGIC 2. Set that as the max basket subset size in the subsets function and register the func as a UDF
# MAGIC 3. Generate subsets from observed baskets and process them into sorted & pipe delimited strings which can be joined into AssocRules DF
# MAGIC 4. From ObsBskts left join AssocRules

# COMMAND ----------

"""
minimize the # of proper subsets derived from observed baskets by: 
  1. identifying max antecedent size 
  2. which becomes the max combi size to take from observed baskets
cap max subset size to 4 since extremely small % of baskets are 5+ items
"""
max_ante_size = (
    assoc_rules.withColumn("bskt_size", F.size("antecedent"))
    .groupBy()
    .agg(F.max("bskt_size").alias("max_bskt_size"))
    .select("max_bskt_size")
    .rdd.map(lambda x: x["max_bskt_size"])
    .collect()
)[0]

max_combi_cap = 4

if max_ante_size > max_combi_cap:
    max_ante_size = max_combi_cap

print(max_ante_size)

# COMMAND ----------

# generate all proper subsets from antecedent itemsets
def proper_subsets_including_self(arr):
    k = max_ante_size
    # generate n choose k combis for all n>=1 and n<=k
    combis = chain.from_iterable(combinations(arr, r) for r in range(1, k + 1))
    # combis returns tuples so convert these into a list of lists
    subsets_lists = [list(subset) for subset in list(combis)]
    return subsets_lists

# COMMAND ----------

properSubsetsInclSelfUDF = F.udf(
    lambda x: proper_subsets_including_self(x), T.ArrayType(T.StringType())
)

# COMMAND ----------

display(
    assoc_rule_antes_nonnullmapns
    # group by antecedent count MAPNs
    .groupBy(fpg_eph_level)
    .agg(F.count("MenuAcmeProductNumber").alias("mapn_cnt"))
    # group by MAPN count collect set of antecedents
    .groupBy("mapn_cnt")
    .agg(F.collect_set(fpg_eph_level).alias(f"{fpg_eph_level}_set"))
    # count antecedents by associated MAPN count, also cummulative running total
    .withColumn(
        f"{fpg_eph_level}_cnt", F.size(f"{fpg_eph_level}_set")
    )
    .withColumn(
        f"{fpg_eph_level}_cnt_rnTtl",
        F.sum(f"{fpg_eph_level}_cnt").over(Window.orderBy("mapn_cnt")),
    )
    # select and order output
    .select(
        "mapn_cnt",
        f"{fpg_eph_level}_cnt",
        f"{fpg_eph_level}_cnt_rnTtl",
        f"{fpg_eph_level}_set",
    )
    .orderBy("mapn_cnt")
)

# COMMAND ----------

# Assoc Rules Antecedents with MAPNs for NPIs
assoc_rule_antes_mapnsfornpis = assoc_rule_antes_nonnullmapns.groupBy().agg(
    F.collect_set(fpg_eph_level).alias("dist_antes_with_mapns_set")
)

display(assoc_rule_antes_mapnsfornpis)

# COMMAND ----------

# withColumn column names
wc_col_names = [
    f"{fpg_eph_level}_set_size",
    f"{settings.ymal_fpg.fpg_antes_only_bskt_col}_size",
    f"{settings.ymal_fpg.fpg_no_antes_bskt_col}_size",
]

lst_bskt_status = ["has_antecedents", "no_antecedents", "ERROR"]
whn_bskt_status = (
    F.when(F.col(wc_col_names[1]) > F.lit(0), F.lit(lst_bskt_status[0]))
    .when(F.col(wc_col_names[1]) == F.lit(0), F.lit(lst_bskt_status[1]))
    .otherwise(F.lit(lst_bskt_status[-1]))
)

# observed baskets
observed_baskets = (
    ob_cnts.crossJoin(assoc_rule_antes_mapnsfornpis)
    .withColumn(
        settings.ymal_fpg.fpg_antes_only_bskt_col,
        F.array_intersect(f"{fpg_eph_level}_set", "dist_antes_with_mapns_set"),
    )
    .withColumn(
        settings.ymal_fpg.fpg_no_antes_bskt_col,
        F.array_except(f"{fpg_eph_level}_set", "dist_antes_with_mapns_set"),
    )
    .drop("dist_antes_with_mapns_set")
    .withColumn(wc_col_names[0], F.size(f"{fpg_eph_level}_set"))
    .withColumn(wc_col_names[1], F.size(settings.ymal_fpg.fpg_antes_only_bskt_col))
    .withColumn(wc_col_names[2], F.size(settings.ymal_fpg.fpg_no_antes_bskt_col))
    .withColumn("basket_status", whn_bskt_status)
)

# display(observed_baskets)

# COMMAND ----------

# count of baskets items with and without MAPNs, grouped by items in basket
display(
    observed_baskets.groupBy(wc_col_names)
    .agg(
        F.count(f"{fpg_eph_level}_set").alias(
            f"{fpg_eph_level}_set_cnt"
        ),
        F.sum("trans_cnt").alias("trans_cnt_sum"),
    )
    .orderBy(wc_col_names)
)

# COMMAND ----------

slct_obao = [settings.ymal_fpg.fpg_antes_only_bskt_col, "trans_cnt"]

# ob_ao : Observed Baskets Antecedents Only
obs_bskts_antes_only = (
    observed_baskets.select(slct_obao)
    # filter to baskets which have 1+ antecedent items in them
    .filter(F.col("basket_status") == F.lit(lst_bskt_status[0]))
    # re-sum trans_cnt b/c some original baskets have had items dropped b/c missing MAPNs, they now match other baskets on {settings.ymal_fpg.fpg_antes_only_bskt_col}
    .groupBy(slct_obao[0])
    .agg(F.sum(slct_obao[1]).alias(slct_obao[1]))
)

# COMMAND ----------

slct_obno = [settings.ymal_fpg.fpg_no_antes_bskt_col, "trans_cnt"]

# ob_no : Observed Baskets No antecednets Only
obs_bskts_no_antes_only = (
    observed_baskets.select(slct_obno)
    .filter(F.col("basket_status") != F.lit(lst_bskt_status[0]))
    # re-sum trans_cnt b/c some original baskets have had items dropped b/c missing MAPNs, they now match other baskets on {settings.ymal_fpg.fpg_antes_only_bskt_col}
    .groupBy(slct_obno[0])
    .agg(F.sum(slct_obno[1]).alias(slct_obno[1]))
    .withColumn("TrainingDate", F.lit(endDate))
    .select("TrainingDate", *slct_obno)
)

# COMMAND ----------

# write baskets with antecednets that have no mapns
(
    obs_bskts_no_antes_only.write.format("delta")
    .mode("overwrite")
    .option("replaceWhere", replaceWhere_trainDate_expr)
    .saveAsTable(settings.ymal_fpg.fpg_bskts_all_antes_no_mapns_table_name)
)

# COMMAND ----------

# create proper subsets out of all baskets (using the UDF) to prepare for joining ARs

# bskts : BaSKeTS to be used for precomputing recos
bskts = (
    obs_bskts_antes_only.select(settings.ymal_fpg.fpg_antes_only_bskt_col, "trans_cnt")
    # run UDF, doesn't change grain, outputs array of subsets (each subset is itself an array)
    .withColumn(
        f"{fpg_eph_level}_subsets",
        properSubsetsInclSelfUDF(settings.ymal_fpg.fpg_antes_only_bskt_col),
    )
    # explode the array of subsets and then concatenate each subset pipe delimited
    .withColumn(
        f"{fpg_eph_level}_subsets",
        F.explode(f"{fpg_eph_level}_subsets"),
    )
    .withColumn(
        f"{fpg_eph_level}_subsets",
        F.split(
            F.regexp_replace(f"{fpg_eph_level}_subsets", r"(\[|\]|\s)", ""),
            ",",
        ),
    )
    .withColumn(
        f"{fpg_eph_level}_subsets",
        F.array_join(F.array_sort(f"{fpg_eph_level}_subsets"), "|"),
    )
    .withColumnRenamed(f"{fpg_eph_level}_subsets", "antecedent_concat")
)

# COMMAND ----------

# after joining into assocRules only need to retain basket & consequent, since those are the two columns that'll need to be re-expressed in terms of MAPNs rather than NPIs
# leaving antecedent in the DF since the grain is a product of antecedent/consequent pairs that match the NPI_set
# join ARs to Bskts

# Precompute Recos All
precomp_recos_all = (
    bskts.join(assoc_rules, ["antecedent_concat"], "left_outer")
    # if consequent for a basket has multiple rows, retain only the row with highest lift
    .withColumn("cons_rank_single", F.rank().over(wdw_bsktCons_lift))
    .filter(F.col("cons_rank_single") == F.lit(1))
    # limit number of consequents per basket
    .withColumn("cons_rank_all", F.rank().over(wdw_bskt_lift))
    .filter(F.col("cons_rank_all") <= F.lit(settings.ymal_fpg.fpg_max_precomp_cons))
)

# COMMAND ----------

fltr_null_ante = F.col("antecedent").isNull()
fltr_null_cons = F.col("consequent").isNull()
fltr_null_lift = F.col("lift").isNull()
fltr_any_nulls = fltr_null_ante | fltr_null_cons | fltr_null_lift

# prm : Precomputed Recos Nulls (in ante, cons or lift)
precomp_recos_nulls = precomp_recos_all.filter(fltr_any_nulls)

# COMMAND ----------

# filter out any rows where any of the reco related columns have a null (every column is required to provide a reco)
precomp_recos = (
    precomp_recos_all.filter(~fltr_any_nulls)
    .select(settings.ymal_fpg.fpg_antes_only_bskt_col, "antecedent", "consequent", "lift")
    .withColumn(
        "basket_sortedStr", F.array_join(F.array_sort("bsktItems_with_mapns_set"), "|")
    )
)

# COMMAND ----------

(
    precomp_recos.write.format("delta")
    .mode("overwrite")
    .saveAsTable(settings.ymal_fpg.fpg_recos_eph_table_name)
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Precomp Recos QA

# COMMAND ----------

# this was taking nearly 5 mins to run, not needed for every refresh tho
# # created exclusive subsets: 43931046+7607806 == 51538852
# precomp_recos_all_cnt = precomp_recos_all.count()  # 51,538,852
# precomp_recos_nulls_cnt = precomp_recos_nulls.count()  # 7,607,806
# pr_cnt = pr.count()  # 43,931,046

# print(f"        All pre-computed recos count: {precomp_recos_all_cnt}")
# print(f"Pre-computed recos with a null count: {precomp_recos_nulls_cnt}")
# print(f"  Pre-computed recos w/o nulls count: {pr_cnt}")
# print(f"Precent of all pre-computed recos w/o nulls: {pr_cnt / precomp_recos_all_cnt:.3f}")
# print(f" Precent of all pre-computed recos w/ nulls: {precomp_recos_nulls_cnt / precomp_recos_all_cnt:.3f}")

# COMMAND ----------

# MONITOR: Distribution of recos per basket
display(
    spark.table(settings.ymal_fpg.fpg_recos_eph_table_name)
    # group by basket count consequents (recos)
    .groupBy(settings.ymal_fpg.fpg_antes_only_bskt_col)
    .agg(
        F.count("consequent").alias("consequent_cnt"),
        F.countDistinct("consequent").alias("consequent_cntDst"),
    )
    # count baskets by reco count
    .groupBy("consequent_cntDst", "consequent_cnt")
    .agg(F.count(settings.ymal_fpg.fpg_antes_only_bskt_col).alias("bskt_cnt"))
    .withColumn("bskt_cnt_ttl", F.sum("bskt_cnt").over(Window.partitionBy()))
    .withColumn(
        "bskt_cnt_runTtl", F.sum("bskt_cnt").over(Window.orderBy("consequent_cntDst"))
    )
    .withColumn(
        "bskt_cnt_cumePerc",
        F.round(F.col("bskt_cnt_runTtl") / F.col("bskt_cnt_ttl"), 3),
    )
    .orderBy("consequent_cntDst", "consequent_cnt")
)

# COMMAND ----------

# QA: check for nulls in antecedents and consequents
# QA PASS == output returns no rows

display(
    spark.table(settings.ymal_fpg.fpg_recos_eph_table_name)
    # count antecednets/consequents (and when null) for every basket
    .groupBy(settings.ymal_fpg.fpg_antes_only_bskt_col)
    .agg(
        F.count("antecedent").alias("ante_cnt"),
        F.count("consequent").alias("cons_cnt"),
        F.count(F.when(F.col("antecedent").isNull(), F.lit(1))).alias("ante_null_cnt"),
        F.count(F.when(F.col("consequent").isNull(), F.lit(1))).alias("cons_null_cnt"),
    )
    # count baskets grouped by ant/cons count and null ant/cons count
    .groupBy("ante_cnt", "cons_cnt", "ante_null_cnt", "cons_null_cnt")
    .agg(
        F.count(settings.ymal_fpg.fpg_antes_only_bskt_col).alias(
            f"{settings.ymal_fpg.fpg_antes_only_bskt_col}_cnt"
        )
    )
    .filter((F.col("ante_null_cnt") > F.lit(0)) | (F.col("cons_null_cnt") > F.lit(0)))
    #    .orderBy('ante_cnt', 'cons_cnt', 'ante_null_cnt', 'cons_null_cnt')
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Enrich baskets with MAPN

# COMMAND ----------

# MAGIC %md
# MAGIC ### Re-express Baskets as MAPNs
# MAGIC
# MAGIC 1. explode basket
# MAGIC 2. join into ARAN on exploded basket items col
# MAGIC 3. group by basket_array, antecedent, cons, lift, agg(collect_set(MAPN))
# MAGIC 4. array_join(array_sort(bskt_mapn_set), '|')

# COMMAND ----------

# prmb = Precomputed Recos with Mapn Baskets
precomp_recos_mapn_bskts = (
    spark.table(settings.ymal_fpg.fpg_recos_eph_table_name)
    # explode basket array & join MAPNs to eph_level column
    .withColumn(fpg_eph_level, F.explode(settings.ymal_fpg.fpg_antes_only_bskt_col))
    .join(assoc_rule_antes_nonnullmapns, [fpg_eph_level], "left_outer")
    # collapse back down to basket/reco grain
    .groupBy(settings.ymal_fpg.fpg_antes_only_bskt_col, "antecedent", "consequent", "lift")
    .agg(F.collect_set("MenuAcmeProductNumber").alias("bsktMapns_set"))
    # create sorted String of NPI array
    .withColumn("bskt_sortedStr", F.array_join(F.array_sort("bsktMapns_set"), "|"))
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Re-express Consequents as MAPNs
# MAGIC
# MAGIC 1. explode consequent
# MAGIC 2. join into ARCN on exploded consequent col
# MAGIC 3. group by Precomp Reco Mapn Antes schema names, agg(collect_set(MAPN))
# MAGIC
# MAGIC - Recos don't need to be expressed as sorted strings, b/c even if an assoc_rules.consequent has 2+ items, reco lists are created on an item by item basis
# MAGIC - so we don't need to make consequent sets we can create 1:1 item mapping
# MAGIC
# MAGIC I think arcn DataFrame can be used b/c each reco just needs to be re-expressed as a MAPN
# MAGIC There will be some cases where 2-6 MAPNs are associated with an NPI consequent, so either take every MAPN or pick one (I lean towards taking every one to create stability in measurement)
# MAGIC

# COMMAND ----------



# prmbc = Precomputed Recos with Mapn Baskets and Consequents
precomp_recos_mapn_bskts_cons = (
    precomp_recos_mapn_bskts
    # explode basket array & join MAPNs to eph_level column
    .withColumn(fpg_eph_level, F.explode("consequent"))
    .join(assoc_rule_cons_nonnullmapns, [fpg_eph_level], "left_outer")

    # check for nulls and remove them, just like for EPH based recos
    .filter(F.col('MenuAcmeProductNumber').isNotNull())

    # remove row 2+ for any mapn consequent, order by lift desc
    .withColumn('bskt_mapn_rows', F.row_number().over(wdw_bsktMapn_lift))
    .filter(F.col('bskt_mapn_rows') == 1)
    .drop('bskt_mapn_rows')

    # set grain to 1 MAPN per consequent, which MAPN(s) to remove is arbitrary since multiple MAPNs per consequent is a product of many:one relationship between PD & EPH tables
        # so as of 2025-01-10 keeping the MAPN with the lowest number
    .withColumn('bsktCons_mapn_rows', F.row_number().over(wdw_bsktCons_mapn))
    .filter(F.col('bsktCons_mapn_rows') == 1)
    .drop('bsktCons_mapn_rows')

    # enforce max consequents of <=64 at this point
    .withColumn('rank_recos_by_lift', F.row_number().over(wdw_bskt_mapn))
    .filter(F.col('rank_recos_by_lift') <= settings.ymal_fpg.fpg_max_precomp_recos)

    # consequent struct to include sizeCode & name with MAPN
    .withColumn(
        "cons_mapn_struct",
        F.struct("MenuAcmeProductNumber", "sizeCode", "productNameEnglishUS"),
    )
    # collapse back down to basket/reco grain
    .groupBy(*precomp_recos_mapn_bskts.schema.names)
    .agg(F.collect_set("cons_mapn_struct").alias("cons_mapn_struct_set"))
)

# COMMAND ----------

(
    precomp_recos_mapn_bskts_cons.write.format("delta")
    .mode("overwrite")
    .saveAsTable(settings.ymal_fpg.fpg_recos_mapn_table_name)
)

# COMMAND ----------

# Monitor: All baskets should have mapn_diff of 0
display(
    spark.table(settings.ymal_fpg.fpg_recos_mapn_table_name)
    .groupBy('bsktItems_with_mapns_set')
    .agg(F.count('cons_mapn_struct_set.MenuAcmeProductNumber').alias('mapn_cnt'),
         F.countDistinct('cons_mapn_struct_set.MenuAcmeProductNumber').alias('mapn_cntDst'))
    .withColumn('mapn_diff', F.col('mapn_cnt') - F.col('mapn_cntDst'))
    .groupBy('mapn_diff').agg(F.count('bsktItems_with_mapns_set').alias('bskt_cnt'))
    .orderBy(F.desc('mapn_diff'))
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Precomp Reco grain to Basket
# MAGIC
# MAGIC - drop antecedent from grain (at this point we don't need to retain antecedent from the associationRule from which the consequent was obtained)
# MAGIC - Array of structs to house the recos (rank and MAPN elements of struct)

# COMMAND ----------

# consequent MenuAcmeProductNumber struct
cons_mapn_struct_keys = ["reco_mapn", "reco_sizeCode", "reco_name"]
cons_mapn_struct_vals = [
    F.col("cons_mapn_struct_set_expl.MenuAcmeProductNumber"),
    F.col("cons_mapn_struct_set_expl.sizeCode"),
    F.col("cons_mapn_struct_set_expl.productNameEnglishUS")
]

cons_mapn_struct_dict = dict(zip(cons_mapn_struct_keys, cons_mapn_struct_vals))

wdw_bsktRank_mapn = (Window
    .partitionBy('bskt_sortedStr', 'reco_rank')
    .orderBy(F.col('reco_mapn'))
)

# COMMAND ----------

# Retain top consequent (based on lift) for each antecedent and then rank recos for each basket
reco = (
    spark.table(settings.ymal_fpg.fpg_recos_mapn_table_name)
    # if one consequent has multiple rules, keep the one with highest lift
    .withColumn("cons_rank", F.rank().over(wdw_bsktCons_lift))
    .filter(F.col("cons_rank") == F.lit(1))
    .drop("cons_rank")
    # rank recos by lift descending
    .withColumn("reco_rank", F.rank().over(wdw_bskt_lift))
    .filter(F.col("reco_rank") <= F.lit(settings.ymal_fpg.fpg_max_precomp_recos))
    .withColumn("reco_rank", F.col("reco_rank").cast(T.StringType()))
)

# COMMAND ----------

# explode consequent_MAPN struct (future proofing for possibility of multi-item consequets)
reco = (reco
    # each item in the multi-item consequent should be assigned the same rank
    .withColumn("cons_mapn_struct_set_expl", F.explode("cons_mapn_struct_set"))
    # unpack the columns in the struct so they can be added to reco_struct but not stored as a stuct within the reco_rank struct
    .withColumns(cons_mapn_struct_dict)        
)

# COMMAND ----------

# resolve cases when multiple mapns are associated with a rank
reco = (reco
    .withColumn('reco_rank_resolve', F.row_number().over(wdw_bsktRank_mapn))
    .filter(F.col('reco_rank_resolve') == F.lit(1))
    .drop('reco_rank_resolve')
)

# COMMAND ----------

# create reco struct, add TrainingDate, group by Basket & TrainingDate, collect structs into array for each basket and convert basket array into pipe delimited string
reco = (reco
    # make struct of [rank, MAPN, name, sizeCode], add snapshotdate
    .withColumn(
        "reco_struct", F.struct("reco_rank", *list(cons_mapn_struct_dict.keys()))
    )
    .withColumn("TrainingDate", F.lit(endDate))
    # # group by snapshotdate & basket, collect_set of struct col
    .groupBy("TrainingDate", settings.ymal_fpg.fpg_antes_only_bskt_col)
    .agg(F.collect_set("reco_struct").alias(settings.ymal_fpg.fpg_reco_list_col_name))
    # trim recos and rename the column
    .withColumn(
        settings.ymal_fpg.fpg_antes_only_bskt_col,
        F.array_join(F.array_sort(settings.ymal_fpg.fpg_antes_only_bskt_col), settings.ymal_fpg.fpg_string_delimiter),
    )
    .withColumnRenamed(settings.ymal_fpg.fpg_antes_only_bskt_col, settings.ymal_fpg.fpg_string_basket_col_name)
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Write outputs

# COMMAND ----------

(
    reco.write.format("delta")
    .mode("overwrite")
    .option("replaceWhere", replaceWhere_trainDate_expr)
    .saveAsTable(settings.ymal_fpg.fpg_reco_snapshots_table_name)
)
