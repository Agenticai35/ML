# YMAL Baseline Recommenders

This is a repo for the You May Also Like (YMAL) recommender, which is a set of challenger models to the GetRecs models/approach. 

## Prerequisites

### Order of Operations according to the DeepBrew Team
_(Source: Vikas Vennavali & Dalavayi Navya)_

1. Create a clone of the https://scm.starbucks.com/deepbrew/experimentation-holdout-service. (Source: Vikas & Navya) [Completed]
2. Change files to suit your usecase.  [Completed]
3. Set-up DataBricks workbooks with a "Production" version to be run on a schedule. [Completed]

### GitHub

Ensure that you're a collaborator in the [deepbrew](https://scm.starbucks.com/deepbrew) GitHub org.

## Installation

Clone this repository to your local machine by typing `git@scm.starbucks.com:deepbrew/ymal-baseline-recommenders.git`.

Run the following command
``` 
poetry install
```

_git clone https://scm.starbucks.com/deepbrew/ymal-baseline-recommenders.git_

To test the API logic, from the base directory the following variables need to be set.
```
set AZURE_CLIENT_ID=''
set AZURE_CLIENT_SECRET=''
set AZURE_TENANT_ID=''
set ENVIRONMENT=dev
set KEYVAULT_NAME=''
set LOCATION=eus2
set STAGE=staging
set API_VERSION=v1
```

then run the following command:

```bash
poetry run pytest
```

This will run the api tests as well as the unit tests configured in the repo.

# Contributing

To make changes, please make your modifications on a branch and open a pull request.

 - Please prefix your branch name with your Starbucks username (e.g.
   `yourusername/fix-bug`) and push it to the shared repo (do not fork).
 - When opening the PR, please say what motivated your changes and describe
   what manual testing steps you have done.
 - Request review from one or more of your co-workers.

#  Local Environment Setup (Using docker containers):

Prerequisite:
-  Docker desktop should be installed in local machine.
-  If using VScode, docker extension to be installed. 

Steps:

1. Clone the module repo on local machine.
2. Create a local.env file in root directory. 
- This file contains environment variables which are used to connect to Azure Keyvault.
- Sample local.env file.
  ```
  ENVIRONMENT="dev"
  LOCATION="eus2"
  KEYVAULT_NAME=""
  TENANT_ID=""
  AZURE_CLIENT_ID=""
  AZURE_TENANT_ID=""
  AZURE_CLIENT_SECRET=""
  REQUESTS_CA_BUNDLE="/usr/local/lib/python3.10/site-packages/certifi/cacert.pem" 
  ```
- Assign values to environment variables based on your requirement.


3. Create config.json file in root directory. 
- This file contains application and model name.
- Sample config.json file contents.
  ```
  {
      "application": "getrecs",
      "model_name": "ymal-baseline"
  }
  ```

4. In Dockerfile_local file, replace user-name and token variables with your Jfrog artifact user name and its's token value.
5. Select docker-compose.yml file and right click on the file name.
-  It will show “Compose Down”, “Compose Restart”, “Compose UP” and “Compose UP – Selected Services” options
- Choose compose UP option to build and run the container in local environment.
- Alternative way is to navigate to the folder where the docker_compose file is present and run ```docker compose up```

The app server should be up and running at port 5000 (as specified in compose file). 

It can be accessed by sending a cURL command to http://localhost:5000/app/getrecs/ymal-baseline-recommender/v1/staging URL.

# Local Debugging (if using vscode):

1. Create a configuration file .vscode/launch.json. 
- This file contains Run and Debug information.
- Sample launch.json file.
  ```
  {
      "version": "0.2.0",
      "configurations": [
          {
              "name": "Python: Remote Attach",
              "type": "python",
              "request": "attach",
              "port": 5678,
              "host": "localhost",
              "pathMappings": [
                  {
                      "localRoot": "${workspaceFolder}",
                      "remoteRoot": "/code_bundle/wrapper_modules"
                  }
              ]
          }
      ]
  }
  ``` 

2. Create a compose file .vscode/docker-compose.debug.yml file. 
- It is similar to docker-compose file, except it uses debugpy and port 5678.
- Sample docker-compose.debug.yml file.
  ```
  version: "3.9"
  services:
    ymal-baseline-service:
      stdin_open: true
      tty: true
      image: "functionasaservice/getrecs_ymal"
      build:
        context: ./../.
        dockerfile: ./Dockerfile_local
      command: ["sh", "-c", "pip install debugpy -t /tmp && python3 /tmp/debugpy --wait-for-client --listen 0.0.0.0:5678 -m uvicorn serving:app --host 0.0.0.0 --port 5000 --reload"]  
      ports:
        - "5000:5000"
        - "5678:5678"
      env_file: 
        - local.env 
  ``` 

3.  Create a local.env file in .vscode directory and add the environment variables. 
4. Start docker-compose debugging by: Right click on docker-compose.debug.yml file and click Compose Up. You can also run command docker compose -f docker-compose.debug.yml up.
5. Go to Run and Debug, select Python: Remote Attach and click Start Debugging button.
6. If there is nothing wrong, the debugger will connect to container and you can add a break point to test it.


