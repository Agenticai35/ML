#!/bin/bash
printf "[global]\n" >> /etc/pip.conf
printf "index-url = https://m-00188-1:$JFROG_TOKEN@binrepo.starbucks.com/artifactory/api/pypi/air-pypi-prod-virtual/simple\n" >> /etc/pip.conf