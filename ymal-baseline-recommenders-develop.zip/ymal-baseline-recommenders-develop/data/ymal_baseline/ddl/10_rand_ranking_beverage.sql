-- Databricks notebook source
CREATE TABLE IF NOT EXISTS you_may_also_like.rand_ranking_beverage (
    productNumber STRING,
    formCode STRING,
    sizeCode STRING,
    type STRING,
    name STRING,
    productTypeName STRING,
    randRanking DOUBLE
) USING DELTA
TBLPROPERTIES (delta.autoOptimize.optimizeWrite = true, 
               delta.autoOptimize.autoCompact = true, 
               'app'='ymal',
               'type'='raw')
LOCATION "/mnt/apps/ymal/data/raw/rand_ranking_beverage/ver=01";