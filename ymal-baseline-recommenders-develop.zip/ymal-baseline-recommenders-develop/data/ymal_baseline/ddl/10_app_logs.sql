%sql
CREATE TABLE IF NOT EXISTS you_may_also_like.app_logs (
  app_param struct<input:struct<app:string,clientId:string,context:string,context1:string,context2:string,context3:string,country:string,currentCartItems:array<string>,dfSessionId:string,dfSessionState:array<string>,externalId:string,items:array<struct<formCode:string,name:string,price:string,productNumber:string,productSku:string,purchaseCount:string,quantity:string,rank:string,sizeCode:string,type:string,variant:string>>,latitude:string,limit:string,localDateTime:string,longitude:string,max:string,maxItemsPerCategory:string,minProductCount:string,preferences:string,productsSelected:array<string>,questionsAns:array<string>,requestTime:string,serverTime:string, sku:string,store:string,user:string,usualItem:string,xCorrelationId:string,xDeepbrewClient:string>,output:struct<items:array<struct<formCode:string,name:string,productNumber:string,rank:string,sizeCode:string,type:string>>,recommendationId:string>>,
asctime string,
dd struct<env:string,service:string,span_id:string,trace_id:string,version:string>,
edap_custom_vars struct<`apim-correlation-id`:string,`request-type`:string,`x-correlation-id`:string>,
funcName string,
levelname string,
message string,
module string,
name string,
namespace string,
process string,
service string,
sink array<string>,
thread string,
timestamp string,
calendarDate date
) USING DELTA PARTITIONED BY (calendarDate) TBLPROPERTIES (
  delta.autoOptimize.optimizeWrite = true,
  delta.autoOptimize.autoCompact = true,
  'app' = 'ymal',
  'type' = 'raw'
) LOCATION "/mnt/apps/ymal/data/raw/app_logs/ver=01";