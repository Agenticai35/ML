-- Databricks notebook source
CREATE SCHEMA IF NOT EXISTS you_may_also_like
COMMENT "You May Also Like (ymal) schema"
LOCATION "/mnt/apps/ymal/data/"
WITH DBPROPERTIES ('app'='ymal');