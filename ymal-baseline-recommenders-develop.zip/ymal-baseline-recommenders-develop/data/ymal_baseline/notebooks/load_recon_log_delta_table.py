# Databricks notebook source
# # Imports
from pyspark.sql.types import StringType, StructType, StructField, MapType, ArrayType, LongType, DoubleType
import configparser
import sys, ast, os, glob
import datetime as dt
from pyspark.sql.functions import col, to_timestamp, lit, when
from pyspark.sql import functions as F 
from pathlib import PurePath
from datetime import datetime, timedelta

# COMMAND ----------

# widgets
dbutils.widgets.text(
    "file_path", "/mnt/apps/prodymal/data/logs/ymal-baseline/", "File Path"
)
dbutils.widgets.text("run_date", "", "Run Date(yyyy-mm-dd)")
dbutils.widgets.text("request_type", "live", "Request Type(Enter list with Comma delimiter)")


file_path = dbutils.widgets.get("file_path")
date_string = dbutils.widgets.get("run_date")
request_type_value = dbutils.widgets.get('request_type')
request_type_values_list = [value.strip() for value in request_type_value.split(',')]

# COMMAND ----------

#schema data fields all string
input_schema = StructType(
    [
        StructField(
            "app_param",
            StructType(
                [
                    StructField(
                        "input",
                        StructType(
                            [
                                StructField("app", StringType(), True),
                                StructField("clientId", StringType(), True),
                                StructField("context", StringType(), True),
                                StructField("context1", StringType(), True),
                                StructField("context2", StringType(), True),
                                StructField("context3", StringType(), True),
                                StructField("country", StringType(), True),
                                StructField(
                                    "currentCartItems",
                                    ArrayType(StringType(), True),
                                    True,
                                ),
                                StructField("dfSessionId", StringType(), True),
                                StructField(
                                    "dfSessionState",
                                    ArrayType(StringType(), True),
                                    True,
                                ),
                                StructField("externalId", StringType(), True),
                                StructField(
                                    "items",
                                    ArrayType(
                                        StructType(
                                            [
                                                StructField(
                                                    "formCode", StringType(), True
                                                ),
                                                StructField("name", StringType(), True),
                                                StructField(
                                                    "price",StringType(), True
                                                ),
                                                StructField(
                                                    "productNumber", StringType(), True
                                                ),
                                                StructField(
                                                    "productSku", StringType(), True
                                                ),
                                                StructField(
                                                    "purchaseCount", StringType(), True
                                                ),
                                                StructField(
                                                    "quantity", StringType(), True
                                                ),
                                                StructField("rank", StringType(), True),
                                                StructField(
                                                    "sizeCode", StringType(), True
                                                ),
                                                StructField("type", StringType(), True),
                                                StructField(
                                                    "variant", StringType(), True
                                                ),
                                            ]
                                        ),
                                        True,
                                    ),
                                    True,
                                ),
                                StructField("latitude", StringType(), True),
                                StructField("limit", StringType(), True),
                                StructField("localDateTime", StringType(), True),
                                StructField("longitude", StringType(), True),
                                StructField("max", StringType(), True),
                                StructField("maxItemsPerCategory", StringType(), True),
                                StructField("minProductCount", StringType(), True),
                                StructField("preferences", StringType(), True),
                                StructField(
                                    "productsSelected",
                                    ArrayType(StringType(), True),
                                    True,
                                ),
                                StructField(
                                    "questionsAns", ArrayType(StringType(), True), True
                                ),
                                StructField("requestTime", StringType(), True),
                                StructField("serverTime", StringType(), True),
                                StructField("sku", StringType(), True),
                                StructField("store", StringType(), True),
                                StructField("user", StringType(), True),
                                StructField("usualItem", StringType(), True),
                                StructField("xCorrelationId", StringType(), True),
                                StructField("xDeepbrewClient", StringType(), True),
                            ]
                        ),
                        True,
                    ),
                    StructField(
                        "output",
                        StructType(
                            [
                                StructField(
                                    "items",
                                    ArrayType(
                                        StructType(
                                            [
                                                StructField(
                                                    "formCode", StringType(), True
                                                ),
                                                StructField("name", StringType(), True),
                                                StructField(
                                                    "productNumber", StringType(), True
                                                ),
                                                StructField("rank", StringType(), True),
                                                StructField(
                                                    "sizeCode", StringType(), True
                                                ),
                                                StructField("type", StringType(), True),
                                            ]
                                        ),
                                        True,
                                    ),
                                    True,
                                ),
                                StructField("recommendationId", StringType(), True),
                            ]
                        ),
                        True,
                    ),
                ]
            ),
            True,
        ),
        StructField("asctime", StringType(), True),
        StructField(
            "dd",
            StructType(
                [
                    StructField("env", StringType(), True),
                    StructField("service", StringType(), True),
                    StructField("span_id", StringType(), True),
                    StructField("trace_id", StringType(), True),
                    StructField("version", StringType(), True),
                ]
            ),
            True,
        ),
        StructField(
            "edap_custom_vars",
            StructType(
                [
                    StructField("apim-correlation-id", StringType(), True),
                    StructField("request-type", StringType(), True),
                    StructField("x-correlation-id", StringType(), True),
                ]
            ),
            True,
        ),
        StructField("funcName", StringType(), True),
        StructField("levelname", StringType(), True),
        StructField("message", StringType(), True),
        StructField("module", StringType(), True),
        StructField("name", StringType(), True),
        StructField("namespace", StringType(), True),
        StructField("process", StringType(), True),
        StructField("service", StringType(), True),
        StructField("sink", ArrayType(StringType(), True), True),
        StructField("thread", StringType(), True),
        StructField("timestamp", StringType(), True),
    ]
)

# COMMAND ----------

# Get the current date
run_date = datetime.strptime(date_string, "%Y-%m-%d")


# Subtract one day to get the previous day or make any other shift
previous_day = run_date - timedelta(days=1)

# Format the date as a string in the desired format if needed
previous_day_str = previous_day.strftime('%Y%m%d')

log_file_path = str(PurePath(file_path, previous_day_str))
print(f"File Path: {file_path}")
print(f"Run Date: {date_string}")
print(f"Request Type: {request_type_values_list}")
print(f"Log File Path: {log_file_path}")

# COMMAND ----------

#Load the files for previous day
log_data_df = (
    spark.read.option("header", "false")
    .schema(input_schema)
    .option("inferSchema", "false")
    .json("{}/*/*.log".format(log_file_path))
    .filter(col('edap_custom_vars').getField('request-type').isin(request_type_values_list))
    .withColumn("calendarDate",F.to_date(F.substring('timestamp',1,10), "yyyy-MM-dd") )

)


total_records = log_data_df.count()
print(f"Total records: {total_records}")
print("Read from 1: {}/*/*.log".format(log_file_path))
                

# COMMAND ----------

#Creating delta table for looking at the data
if total_records > 0 :
    (
        log_data_df
        .write
        .partitionBy("calendarDate")
        .mode("overwrite")
        .format("delta")
        .option("replaceWhere", f"calendarDate = '{previous_day.strftime('%Y-%m-%d')}'")
        .saveAsTable("you_may_also_like.app_logs")
    )
