# Databricks notebook source
# MAGIC %md
# MAGIC ### Imports

# COMMAND ----------

import sys, os
import datetime as dt
import json
import glob
from abc import abstractmethod

import uuid
import configparser
from pyspark.sql.types import BinaryType, StringType, StructField, StructType
import pyspark.sql.functions as F
from pyspark.sql import DataFrame
from pyspark.sql.session import SparkSession
from pyspark.context import SparkContext
from pyspark.sql.utils import AnalysisException

from edap_keyvault.key_vault import KeyVault

from typing import TypeVar, Type
from pathlib import Path
from dynaconf import Dynaconf


# COMMAND ----------

# Define username for path to settings file
# lst_user_names = ['keadams@starbucks.com', 'dnavya@starbucks.com', 'andwong@starbucks.com']
# dbutils.widgets.dropdown('user_path', lst_user_names[0], lst_user_names)
dbutils.widgets.text("settings_path", defaultValue="/Workspace/Repos/shared/ymal-baseline-recommenders/settings.toml")

# variant name must be the name of a class built on DataLoader class, because main accepts variant_name as the value for the load_type arg, and load_type is passed as the arg for classes class which registers a class by the name of load_type, which originates from variant_name which should be SimpleRandomSample since that is the one class built on DataLoader
lst_variant_names = ['SimpleRandomSample']
dbutils.widgets.dropdown('variant_name', lst_variant_names[0], lst_variant_names)

# COMMAND ----------

# define full path to settings file and read it into a Dynaconf object
settings_path = dbutils.widgets.get('settings_path')

config = Dynaconf(settings_files=[settings_path], environments = True).as_dict()

# COMMAND ----------

# set Current Database to that specified by Dynaconf object
print(f"Setting database to: {config['YMAL_SCHEMA']}")
spark.catalog.setCurrentDatabase(config['YMAL_SCHEMA'])

# COMMAND ----------

class Config:
    """
        Class to load the configurations from the config path.

        methods :
            get_config(config, environment: str) -> dict
    """

    def __init__(self, db_utils):
        keyvault_util = KeyVault(dbutils=db_utils)
        self.configs: dict = self.get_config(settings_path)
        print(self.configs)
        self.redis_config = json.loads(keyvault_util.get_secret(config['REDIS_CONNECTION_SECRET_NAME']))


    @staticmethod
    def get_config(settings_path: str) -> dict:
        # Create a Dynaconf instance  
        settings: dict = Dynaconf(settings_files=[settings_path], environments = True).as_dict()
        return settings


# COMMAND ----------

class DataLoader:
    """
        Contains the definition of write cache data methods for all the cache classes.

        methods:
            - read_data(self) -> DataFrame
            - process_data(self)
    """

    def __init__(self, context: SparkContext, session: SparkSession, config: Config):
        self.context: SparkContext = context
        self.session: SparkSession = session
        self.config: Config = config

    @abstractmethod
    def read_data(self) -> DataFrame:
        pass

    @abstractmethod
    def process_data(self):
        pass

    def write_data(self, df: DataFrame, db_table: str, db_key: str, mode='Append'):
        df_coal = df.coalesce(4)
        (df_coal
         .write
         .format("org.apache.spark.sql.redis")
         .option("host", self.config.redis_config['host'])
         .option("port", self.config.redis_config['port'])
         .option("auth", self.config.redis_config['password'])
         .option("ssl", 'true')
         .option("table", db_table)
         .option("key.column", db_key)
         .mode(mode)
         .save()
         )


# COMMAND ----------

classes = {}

def register(cls):
    """
    Create a dict of classes that are used to load data to Redis. Using this approach to create
    objects dynamically.
    """
    classes[cls.__name__] = cls
    return cls


# COMMAND ----------

@register
class SimpleRandomSample(DataLoader):
    """
        SimpleRandomSample class to read, process and write the updated data to Redis cache tables.

        methods:
            - read_data(self)     # Reads the table from ADLS
            - write_data(self)    # Writes data to a Redis DB
            - process_data(self)  # Executes read and write functions in a serial manner.
    """

    MODE: str = "Append"

    def __init__(self, context: SparkContext, session: SparkSession, config: Config):
        super().__init__(context, session, config)

    def read_data(self):
        '''Reads the table from ADLS'''
        bev_tbl = self.config.configs['BEV_TABLE_NAME']
        beverage_df = (self
              .session
              .table(bev_tbl)
              )
        print(f'SUCCESS: Read data {self.__class__} from table {bev_tbl}, count:{beverage_df.count()}')        

        food_tbl = self.config.configs['FOOD_TABLE_NAME']
        food_df = (self
              .session
              .table(food_tbl)
              )
        print(f'SUCCESS: Read data {self.__class__} from table {food_tbl}, count:{food_df.count()}')

        return food_df, beverage_df

    def write_data(self, df: DataFrame, db_table: str, db_key: str, mode='Append'):
        ''' Writes data to a Redis DB '''
        column_name = "ProductTypeName"
        # Concatinating the workspace name to the table name while writing to redis.
        db_table = f"{self.config.redis_config['workspace']}:{db_table}"
        cols: list = df.columns
        df = df.withColumn("json", F.to_json(F.struct(cols)))
        df = df.groupBy(column_name) \
            .agg(F.to_json(F.collect_list("json")).alias("Values")) \
            .select(column_name, "Values")
        df = df.withColumnRenamed(column_name, db_key)
        df = df.withColumn(db_key, F.lit(db_key.lower()))
        # df_coal = df.coalesce(1)
        (df
         .write
         .format("org.apache.spark.sql.redis")
         .option("host", self.config.redis_config['host'])
         .option("port", self.config.redis_config['port'])
         .option("auth", self.config.redis_config['password'])
         .option("ssl", 'true')
         .option("table", db_table)
         .option("key.column", db_key)
         .option("iterator.grouping.size", 100)
         .option("max.pipeline.size", 50)
         .option("scan.count", 100)
         .option("ttl",  2764800)
         .mode(mode)
         .save()
         )

    def process_data(self):
        ''' Internally calls read_data() then write_data() to write whatever has been read, into a Redis DB'''
        food_df, beverage_df = self.read_data()
        self.write_data(food_df, self.config.configs['REDIS_TABLE_NAME'], 'Food')
        self.write_data(beverage_df, self.config.configs['REDIS_TABLE_NAME'], 'Beverage')
        print(f'SUCCESS: Process data {self.__class__}')


# COMMAND ----------

T = TypeVar('T', bound=DataLoader)


def main(load_type: Type[T]):
    sc = SparkContext.getOrCreate()
    spark = SparkSession.getActiveSession()
    conf = Config(dbutils)

    try:
        data_loader = classes[load_type](sc, spark, conf)
        data_loader.process_data()
    except AnalysisException as ex:
        print(ex)
        raise ex
    except OSError as ex:
        print(ex)
        raise ex
    except Exception as ex:
        print(ex)
        print("Load type needs be a type of DataLoader")
        print("Input parameter provided needs to match the name of the class")
        raise ex

# COMMAND ----------

if __name__ == '__main__':

    # Grab the value from the ADF user defined parameter.
    variant_name = dbutils.widgets.get("variant_name")
    print(f"Running redis load for variant: {variant_name}")

    # Function which calls the notebook logic to update Redis cache based on the upload type.
    main(variant_name)
