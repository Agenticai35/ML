# Databricks notebook source
# MAGIC %md
# MAGIC # Notebook Summary
# MAGIC -----
# MAGIC ### Daily load to input dataset for YMAL-Frequent Pattern Growth (FPG) Variant
# MAGIC -----
# MAGIC -----
# MAGIC ##### TLI Extract
# MAGIC - Extract last 3 days of complete data from T360 Line Item
# MAGIC - Filter for Customer Transactions from US SR members, at non-Roastery stores
# MAGIC - Aggregate to 1 row per ParentItemId in the transaction
# MAGIC
# MAGIC ##### EPH Extract
# MAGIC - Get the ID columns for all levels of the hierarchy (except modifiers)
# MAGIC - rename ItemID to ParentItemId
# MAGIC
# MAGIC ##### Join EPH to TLI
# MAGIC - From TLI left join EPH on ParentItemId
# MAGIC
# MAGIC ##### Aggregate TLI+EPH
# MAGIC - 1 row per transaction
# MAGIC - Collect the set of IDs at every level of the EPH (from ParentItemId to ProductTypeId)
# MAGIC
# MAGIC ##### Overwrite data for date range in output table

# COMMAND ----------

dbutils.widgets.text("settings_path", defaultValue="/Workspace/Repos/shared/ymal-baseline-recommenders/settings.toml")

# COMMAND ----------

from pyspark.sql import functions as F, types as T, Window

import datetime as dt, time, math, numpy as np, os, re

from dynaconf import Dynaconf

# COMMAND ----------

settings_path = dbutils.widgets.get("settings_path")

# Create a Dynaconf instance
settings = Dynaconf(settings_files=[settings_path], environments=True)

# COMMAND ----------

spark.catalog.setCurrentDatabase(settings.ymal_schema)

# COMMAND ----------

# set date range to be yesterday and the two days preceding it
day_lag = settings.ymal_fpg.fpg_input_lag_days
days_range = settings.ymal_fpg.fpg_input_days_range

pre_lag_end_date = dt.date.today()
endDate = pre_lag_end_date - dt.timedelta(days=day_lag)
startDate = endDate - dt.timedelta(days=days_range - 1)

print("T360 actuals date range: {0} -> {1}".format(startDate, endDate))

# COMMAND ----------

# must wait to filter out ProductTypeID until that column is in the DF after joining eph to tli
cond_invalid_prodtypeids = F.expr(f"ProductTypeID in ({settings.ymal_fpg.invalid_prodtypeids})")

# COMMAND ----------

# cluster setup
max_workers = 4
cores_per_worker = 4
max_cores = max_workers * cores_per_worker

# processing reqs (partitions per day will depend on worker core size, 16 was chosen for Standard_DS3_v2 workers)
current_partitions = int(spark.conf.get("spark.sql.shuffle.partitions"))
days_in_range = int((endDate - startDate).days + 1)
partitions_per_day = 32
ttl_partitions_reqd = days_in_range * partitions_per_day

# update spark sql shuffle partitions if needed
if ttl_partitions_reqd > current_partitions:
    print(
        f"Need more Partitions!! Have {current_partitions}, need at least {ttl_partitions_reqd}"
    )
    shfl_ptn_fctr = math.ceil(ttl_partitions_reqd / max_cores)
    new_shfl_partitions = max_cores * shfl_ptn_fctr
    spark.conf.set("spark.sql.shuffle.partitions", new_shfl_partitions)
    print(
        f"Shuffle partitions set to: {spark.conf.get('spark.sql.shuffle.partitions')}"
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ### Extract & Aggregate from source tables

# COMMAND ----------

cond_cntry_us = F.expr(settings.ymal_fpg.cond_cntry_us)
cond_roastery = F.expr(settings.ymal_fpg.cond_roastery)

# rs : Roastery Stores
rs = (
    spark.table(settings.ymal_fpg.src_tbl_store_det)
    .filter(cond_cntry_us & cond_roastery)
    .select("StoreNumber")
    .distinct()
)

# lst_rs : LiST of Roastery Stores
lst_rs = rs.rdd.map(lambda x: x["StoreNumber"]).collect()

print(lst_rs)

# COMMAND ----------

slct_eph = [
    "ProductTypeID",
    "ProductCategoryID",
    "ProductStyleID",
    "NotionalProductlID",
    "MarketedProductID",
    "SellableItemID",
    "ItemID",
]

# eph : Enterprise Product Hierarchy
eph = (
    spark.table(settings.ymal_fpg.src_tbl_eph)
    .select(slct_eph)
    .withColumnRenamed("ItemID", "ParentItemId")
)

# COMMAND ----------

# filters
date_range = F.col("BusinessDate").between(startDate, endDate)
customer_trans = F.expr(settings.ymal_fpg.customer_trans) & F.expr(settings.ymal_fpg.non_void)
roastery_stores = F.col("StoreNumber").isin(lst_rs)
lst_lylty_pgms = settings.ymal_fpg.lst_lylty_pgms
us_sr = F.col("LoyaltyProgramName").isin(lst_lylty_pgms[1])

# group & aggregate
grp = [
    "BusinessDate",
    "CustomerOrderChannelName",
    "DayPartCode",
    "SalesTransactionId",
    "ParentItemId",
]
agg_expr = [F.sum("NetDiscountedSalesRevenueAmount").alias("nds_sum")]

# tli : Transaction360 Line Item
tli = (
    spark.table(settings.ymal_fpg.src_tbl_t360_li)
    .filter(date_range & customer_trans & ~roastery_stores & us_sr)
    .groupBy(grp)
    .agg(*agg_expr)
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Enrich source tables

# COMMAND ----------

# tlieph T360 Line Item + Enterprise Product Hierarchy
tlieph = tli.join(eph, ["ParentItemId"], "left_outer").filter(~cond_invalid_prodtypeids)

# COMMAND ----------

grp = ["BusinessDate", "CustomerOrderChannelName", "DayPartCode", "SalesTransactionId"]
agg = [
    "ParentItemId",
    "SellableItemID",
    "MarketedProductID",
    "NotionalProductlID",
    "ProductStyleID",
    "ProductCategoryID",
    "ProductTypeID",
]

agg_expr = [
    F.collect_set(agg[0]).alias(f"{agg[0]}_set"),
    F.collect_set(agg[1]).alias(f"{agg[1]}_set"),
    F.collect_set(agg[2]).alias(f"{agg[2]}_set"),
    F.collect_set(agg[3]).alias(f"{agg[3]}_set"),
    F.collect_set(agg[4]).alias(f"{agg[4]}_set"),
    F.collect_set(agg[5]).alias(f"{agg[5]}_set"),
    F.collect_set(agg[6]).alias(f"{agg[6]}_set"),
]

bskt = tlieph.groupBy(grp).agg(*agg_expr)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Write output

# COMMAND ----------

rplcwhr_expr = f"BusinessDate between '{startDate}' and '{endDate}'"

# COMMAND ----------

(
    bskt.write.format("delta")
    .mode("overwrite")
    .option("replaceWhere", rplcwhr_expr)
    .partitionBy("BusinessDate")
    .saveAsTable(settings.ymal_fpg.fpg_input_table_name)
)
