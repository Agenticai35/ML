-- Databricks notebook source
CREATE TABLE IF NOT EXISTS spark_catalog.you_may_also_like.fpg_bskts_all_antes_no_mapns (
  TrainingDate DATE,
  bsktItems_wo_mapns_set ARRAY<STRING>,
  trans_cnt BIGINT
)
USING delta
PARTITIONED BY (TrainingDate)
LOCATION '/mnt/apps/ymal/fpg/data/raw/fpg_bskts_all_antes_no_mapns/ver=01'
TBLPROPERTIES (
    delta.autoOptimize.optimizeWrite = true, 
    delta.autoOptimize.autoCompact = true, 
    'app'='ymal',
    'variant'='fpg',
    'type'='raw'
);
