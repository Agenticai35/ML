-- Databricks notebook source
CREATE TABLE IF NOT EXISTS spark_catalog.you_may_also_like.fpg_assoc_rules_latest (
  antecedent ARRAY<STRING>,
  consequent ARRAY<STRING>,
  confidence DOUBLE,
  lift DOUBLE,
  support DOUBLE,
  antecedent_concat STRING)
USING delta
LOCATION '/mnt/apps/ymal/fpg/data/raw/fpg_assoc_rules_latest/ver=01'
TBLPROPERTIES (
    delta.autoOptimize.optimizeWrite = true, 
    delta.autoOptimize.autoCompact = true, 
    'app'='ymal',
    'variant'='fpg',
    'type'='raw'
)