-- Databricks notebook source
CREATE TABLE IF NOT EXISTS spark_catalog.you_may_also_like.fpg_reco_default_snapshots (
    TrainingDate DATE,
    reco_ranked_list ARRAY<STRUCT<reco_rank: STRING, reco_mapn: STRING, reco_name: STRING, reco_sizeCode: STRING>>
) 
USING DELTA
PARTITIONED BY (TrainingDate)
LOCATION '/mnt/apps/ymal/fpg/data/raw/fpg_reco_defaults/ver=01'
TBLPROPERTIES (
    delta.autoOptimize.optimizeWrite = true, 
    delta.autoOptimize.autoCompact = true, 
    'app'='ymal',
    'variant'='fpg',
    'type'='raw'
);
