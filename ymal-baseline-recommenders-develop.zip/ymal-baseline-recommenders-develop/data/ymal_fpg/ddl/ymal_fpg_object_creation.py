# Databricks notebook source
# MAGIC %md
# MAGIC ####Imports

# COMMAND ----------

dbutils.widgets.text(
    "settings_path",
    defaultValue="/Workspace/Repos/shared/ymal-baseline-recommenders/settings.toml",
)

# COMMAND ----------

#import json
from edap_keyvault.key_vault import KeyVault
from edap_repo.factory.repo_factory import RepoFactory, RepoType

from dynaconf import Dynaconf
import json

# COMMAND ----------

settings_path = dbutils.widgets.get("settings_path")

# Create a Dynaconf instance
settings = Dynaconf(settings_files=[settings_path], environments=True)

# COMMAND ----------

# MAGIC %md
# MAGIC ####PostgreSQL connection

# COMMAND ----------

keyvault_util = KeyVault(dbutils=dbutils)

cosmos_postgres_connection_key = (
    settings.ymal_fpg.FPG_POSTGRES_CONNECTION_SECRET
)

postgres_connection_dict = json.loads(
    keyvault_util.get_secret(cosmos_postgres_connection_key)
)

config = {"connection_parameters": postgres_connection_dict}
factory = RepoFactory()
repo_handler = factory.create(RepoType.COSMOS_PGSQL, **config)
py_connection_string = (
    repo_handler.postgresql_session.connection_parameters.py_connection_string
)

# COMMAND ----------

# MAGIC %md
# MAGIC ####Schema Creation

# COMMAND ----------

repo_handler.execute("CREATE SCHEMA IF NOT EXISTS ymal")

# COMMAND ----------

# MAGIC %md
# MAGIC ####Table creation

# COMMAND ----------

repo_handler.execute("""
    CREATE TABLE IF NOT EXISTS ymal.fpg_reco (
    bskt_sortedStr_mapn TEXT,
    reco_ranked_list VARCHAR(4000),
    run_id INTEGER
) PARTITION BY LIST (run_id)
""")

# COMMAND ----------

# MAGIC %md
# MAGIC ####Sequence Creation

# COMMAND ----------

repo_handler.execute("CREATE SEQUENCE IF NOT EXISTS ymal.run_id_seq")
