-- Databricks notebook source
CREATE TABLE IF NOT EXISTS spark_catalog.you_may_also_like.fpg_precomp_recos_mapn (
  bsktItems_with_mapns_set ARRAY<STRING>,
  antecedent ARRAY<STRING>,
  consequent ARRAY<STRING>,
  lift DOUBLE,
  bsktMapns_set ARRAY<STRING>,
  bskt_sortedStr STRING,
  cons_mapn_struct_set ARRAY<STRUCT<MenuAcmeProductNumber: STRING, sizeCode: STRING, productNameEnglishUS: STRING>>)
USING delta
LOCATION '/mnt/apps/ymal/fpg/data/raw/fpg_precomp_recos_mapn/ver=01'
TBLPROPERTIES (
    delta.autoOptimize.optimizeWrite = true, 
    delta.autoOptimize.autoCompact = true, 
    'app'='ymal',
    'variant'='fpg',
    'type'='raw'
)