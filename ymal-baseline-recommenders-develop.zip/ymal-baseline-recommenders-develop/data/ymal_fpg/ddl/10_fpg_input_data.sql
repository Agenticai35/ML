-- Databricks notebook source
CREATE TABLE IF NOT EXISTS spark_catalog.you_may_also_like.fpg_input_data (
    BusinessDate DATE,
    CustomerOrderChannelName STRING,
    DayPartCode STRING,
    SalesTransactionId STRING,
    ParentItemId_set ARRAY<STRING>,
    SellableItemID_set ARRAY<STRING>,
    MarketedProductID_set ARRAY<STRING>,
    NotionalProductlID_set ARRAY<STRING>,
    ProductStyleID_set ARRAY<STRING>,
    ProductCategoryID_set ARRAY<STRING>,
    ProductTypeID_set ARRAY<STRING>
) 
USING DELTA
PARTITIONED BY (BusinessDate)
LOCATION '/mnt/apps/ymal/fpg/data/raw/fpg_input_data/ver=01'
TBLPROPERTIES (
    delta.autoOptimize.optimizeWrite = true, 
    delta.autoOptimize.autoCompact = true, 
    'app'='ymal',
    'variant'='fpg',
    'type'='raw'
);
