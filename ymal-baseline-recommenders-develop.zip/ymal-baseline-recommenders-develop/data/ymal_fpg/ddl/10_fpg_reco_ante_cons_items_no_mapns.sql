-- Databricks notebook source
CREATE TABLE IF NOT EXISTS spark_catalog.you_may_also_like.fpg_ante_cons_items_no_mapns (
  MenuAcmeProductNumber STRING,
  NotionalProductlID STRING,
  ProductTypeDescription STRING,
  AssocRuleType STRING,
  TrainingDate DATE
)
USING delta
PARTITIONED BY (TrainingDate)
LOCATION '/mnt/apps/ymal/fpg/data/raw/fpg_ante_cons_items_no_mapns/ver=01'
TBLPROPERTIES (
    delta.autoOptimize.optimizeWrite = true, 
    delta.autoOptimize.autoCompact = true, 
    'app'='ymal',
    'variant'='fpg',
    'type'='raw'
);
