-- Databricks notebook source
CREATE SCHEMA IF NOT EXISTS you_may_also_like
COMMENT "You May Also Like (ymal) - Frequent Pattern Growth (fpg) - schema"
LOCATION "/mnt/apps/ymal/fpg/data/"
WITH DBPROPERTIES ('app'='ymal',
                   'variant'='fpg');