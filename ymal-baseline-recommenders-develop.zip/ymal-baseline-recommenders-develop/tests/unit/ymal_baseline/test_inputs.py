from app.ymal_baseline.input_validator import PayloadValidator
import pytest

def test_validate_input_experiment():
    '''Checking if the payload validator raises an expection in case of malformed request body'''
    payload = {
            }
    with pytest.raises(Exception) as exc:
        PayloadValidator(**payload)
    assert "missing 4 required positional arguments" in str(exc.value)
