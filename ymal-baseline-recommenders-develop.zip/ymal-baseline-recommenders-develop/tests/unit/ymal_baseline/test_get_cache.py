
def test_get_cache(cache, payload: dict, cache_out: dict):
    '''Testing the get_cache method to obtain the patched output'''
    out = cache.get_cache(payload.get('store'), int(payload.get('items')[0]['productNumber']))
    assert out == cache_out

def test_get_simple_recs(cache, simple_random_recos:dict):
    '''Testing for complimentary recommendations from simple random recs'''
    simple_out = cache.get_simple_random_recs('Food')
    assert simple_out == simple_random_recos['Beverage']

  