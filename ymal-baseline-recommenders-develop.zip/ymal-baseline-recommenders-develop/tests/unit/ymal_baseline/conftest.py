import pytest
import uuid
from pathlib import Path
import sys
import json

file_path = Path(__file__).resolve()
root_directory = file_path.parents[3]
sys.path.append(str(root_directory))

from app.utils.filter_inventory import FilterInventory
from app.ymal_baseline.config import ConfigurationManager
from app.ymal_baseline.get_cache import Cache
from app.ymal_baseline.predict import Model as YMAL


@pytest.fixture(scope="class")
def config() -> ConfigurationManager:
    '''Config manager object'''
    return ConfigurationManager()

@pytest.fixture()
def default_reco() -> dict:
    '''Default recommendation object'''
    with open(Path(Path(__file__).parents[3], "app", "ymal_baseline", "config", "default_reco.json")) as f:
        return json.load(f)

@pytest.fixture()
def product_category_map() -> dict:
    '''Product category map sample'''
    return {2122893: "Beverage", 407: "Food"}


@pytest.fixture()
def recos() -> list:
    '''Recommendations post inventory check'''
    return [
        {
            "productNumber": "2122893",
            "formCode": "Iced",
            "sizeCode": "Grande",
            "type": "baselineYMALrecommender-simpleRandomTop10",
            "name": "Vanilla Nitro Cold Brew with Cold Foam",
            "productTypeName": "Beverage",
            "randRanking": 0.11741418631784939,
        },
        {
            "productNumber": "2122326",
            "formCode": "Iced",
            "sizeCode": "Grande",
            "type": "baselineYMALrecommender-simpleRandomTop10",
            "name": "Nitro Cold Brew Float",
            "productTypeName": "Beverage",
            "randRanking": 0.11691546541953546,
        },
        {
            "productNumber": "2123774",
            "formCode": "Iced",
            "sizeCode": "Grande",
            "type": "baselineYMALrecommender-simpleRandomTop10",
            "name": "Chai Tea Latte with Pumpkin Cream Cold Foam",
            "productTypeName": "Beverage",
            "randRanking": 0.1159661250625903,
        },
        {
            "productNumber": "2122725",
            "formCode": "Iced",
            "sizeCode": "Grande",
            "type": "baselineYMALrecommender-simpleRandomTop10",
            "name": "Mango Dragonfruit Refresher",
            "productTypeName": "Beverage",
            "randRanking": 0.1155250942513194,
        },
        {
            "productNumber": "873068741",
            "formCode": "Iced",
            "sizeCode": "Grande",
            "type": "baselineYMALrecommender-simpleRandomTop10",
            "name": "Iced Coffee",
            "productTypeName": "Beverage",
            "randRanking": 0.113764853432755,
        },
        {
            "productNumber": "2123254",
            "formCode": "Iced",
            "sizeCode": "Grande",
            "type": "baselineYMALrecommender-simpleRandomTop10",
            "name": "Nitro Cold Brew with Cinnamon Almond Cold Foam",
            "productTypeName": "Beverage",
            "randRanking": 0.10257414675661058,
        },
        {
            "productNumber": "2122419",
            "formCode": "Iced",
            "sizeCode": "Grande",
            "type": "baselineYMALrecommender-simpleRandomTop10",
            "name": "Nitro Cold Brew with Caramel Cold Foam",
            "productTypeName": "Beverage",
            "randRanking": 0.0831029185667409,
        },
        {
            "productNumber": "2122647",
            "formCode": "Iced",
            "sizeCode": "Grande",
            "type": "baselineYMALrecommender-simpleRandomTop10",
            "name": "Cappuccino with Cold Foam",
            "productTypeName": "Beverage",
            "randRanking": 0.07864688259422226,
        },
        {
            "productNumber": "2123368",
            "formCode": "Iced",
            "sizeCode": "Grande",
            "type": "baselineYMALrecommender-simpleRandomTop10",
            "name": "Honey Almondmilk Nitro Cold Brew",
            "productTypeName": "Beverage",
            "randRanking": 0.06763406396222149,
        },
        {
            "productNumber": "439",
            "formCode": "Iced",
            "sizeCode": "Grande",
            "type": "baselineYMALrecommender-simpleRandomTop10",
            "name": "Matcha Green Tea Crème Frappuccino",
            "productTypeName": "Beverage",
            "randRanking": 0.0656247877169539,
        },
        {
            "productNumber": "2123734",
            "formCode": "Iced",
            "sizeCode": "Grande",
            "type": "baselineYMALrecommender-simpleRandomTop10",
            "name": "Nitro Cold Brew with Cinnamon Caramel Sweet Cream Cold Foam",
            "productTypeName": "Beverage",
            "randRanking": 0.06193811686440587,
        },
        {
            "productNumber": "2122899",
            "formCode": "Iced",
            "sizeCode": "Grande",
            "type": "baselineYMALrecommender-simpleRandomTop10",
            "name": "Black and White Mocha",
            "productTypeName": "Beverage",
            "randRanking": 0.05758227723004705,
        },
    ]


@pytest.fixture()
def simple_random_recos() -> dict:
    '''Simple random sample recommendations sample'''
    return {
        "Food": [
            '{"productNumber":"407","formCode":"Single","sizeCode":"1 Piece","type":"baselineYMALrecommender-simpleRandomTop10","name": "Donut","productTypeName":"Food","randRanking":0.9995947599082471}',
        ],
        "Beverage": [
            '{"productNumber":"2123141","formCode":"Iced","sizeCode":"Grande","type":"baselineYMALrecommender-simpleRandomTop10","name":"Nitro Cold Brew with Pumpkin Cream Cold Foam","productTypeName":"Beverage","randRanking":0.9995947599082471}',
        ],
    }


@pytest.fixture()
def inventory_data() -> dict:
    '''Inventory data sample'''
    return {
        "Iced": [
            2123141,
            775,
        ],
    }


@pytest.fixture()
def cache_out(inventory_data: dict, simple_random_recos: dict) -> dict:
    '''get_cache method output.'''
    return {"inventory": inventory_data, "simple_random_sample_recs": simple_random_recos['Beverage']}


@pytest.fixture()
def cache(monkeypatch,
          config: ConfigurationManager,
          inventory_data: dict,
          product_category_map: dict,
          simple_random_recos:dict):
    '''Patching the caching class to skip the redis calls.'''

    def patched_init(self, *args, **kwargs):
        super(Cache, self).__init__(*args, **kwargs)
        self.getrecs_repo_handler = self.ddt_repo_handler = None
        self.config_manager = config

    def patched_get_inventory(self, *args, **kwargs):
        return inventory_data

    def patched_product_category_mapping(self, *args, **kwargs):
        return product_category_map

    def patched_simple_data(self, *args, **kwargs):
        return simple_random_recos

    monkeypatch.setattr(Cache, "__init__", patched_init)
    monkeypatch.setattr(Cache, "get_inventory_details", patched_get_inventory)
    monkeypatch.setattr(
        Cache,
        "set_product_category_mapping",
        patched_product_category_mapping
    )
    monkeypatch.setattr(
        Cache,
        "set_simple_random_sample_data",
        patched_simple_data
    )

    yield Cache()


@pytest.fixture()
def ymal(monkeypatch,
         config: ConfigurationManager,
         cache: Cache,
         default_reco: dict):
    '''Patching the Model class to use the patched cache class.'''

    def patched_init(self, *args, **kwargs):
        super(YMAL, self).__init__(*args, **kwargs)
        self.cache_object = cache
        self.config_manager = config
        self.default_recommendations = default_reco

    monkeypatch.setattr(YMAL, "__init__", patched_init)
    yield YMAL()

@pytest.fixture()
def inventory_filter():
    '''Inventory Filter for filtering available recommendation'''
    yield FilterInventory()

@pytest.fixture()
def payload() -> dict:
    '''Input request body for testing'''
    return {
        "user": str(uuid.uuid4()),
        "store": "11329",
        "serverTime": "2023-02-13T02:10:00Z",
        "items": [{"productNumber": "407"}],
        "max": 10,
    }
