from app.ymal_baseline.config import ConfigurationManager

class TestConfiguration:

    def test_model_threshold(self, config: ConfigurationManager):
        '''Testing parameter fetch from config'''
        settings_dict = config.get_settings()
        assert settings_dict.ymal_baseline.DEFAULT_MIN_RECOS == 4
