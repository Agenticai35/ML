import json

def test_predict(payload, ymal):
    '''Testing end to end predict function.'''
    output = ymal.predict(payload)
    assert isinstance(output, dict)

def test_predict_filter_inventory(inventory_filter, simple_random_recos, inventory_data):
    """
    Checking if the product 2123141 (beverage product) is in inventory.
    """
    output = inventory_filter.filter_inventory(simple_random_recos['Beverage'], inventory_data)
    assert output[0] == json.loads(simple_random_recos['Beverage'][0])

def test_randomize_recommendations_empty_reco(ymal):
    """
    Testing less than min recommendations conditions.
    """
    assert (
        len(ymal.randomize_recommendations([], 10)["items"])
        == 0
    )

def test_randomize_recommendations_min_reco(ymal, recos):
    """
    Testing min recommendations conditions.
    """
    assert (
        len(ymal.randomize_recommendations(recos[:6], 10)["items"])
        == 6
    )

def test_randomize_recommendations_max_recs(ymal, recos):
    """
    Testing max_recos condition.
    """
    assert len(ymal.randomize_recommendations(recos[:10], 10)["items"]) == 10
