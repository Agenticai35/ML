from app.utils.filter_inventory import FilterInventory
from attrs import asdict
import pytest
import logging

logger = logging.getLogger(__name__)


def test_filter_inventory(inventory_data, fetched_recos_formatted):
    """Test inventory filter logic"""
    available_products = FilterInventory.filter_inventory_no_form_code(fetched_recos_formatted, inventory_data)
    required_result = {"1130", "2122725", "2121219", "2122714", "2122117"}
    available_items = set()
    for product in available_products:
        available_items.add(product.get("productNumber"))
    logger.info(available_items)

    assert available_items == required_result
    assert isinstance(available_products, list)


def test_form_code_key(inventory_data, fetched_recos_formatted):
    """Test whether the filtered inventory output has formCode added against the items"""
    available_products = FilterInventory.filter_inventory_no_form_code(fetched_recos_formatted, inventory_data)
    assert "formCode" in available_products[0].keys()
    assert available_products[0]["formCode"] in inventory_data.keys()
