import pytest

from app.utils.exceptions import MinRecosNotMetException


def test_predict_zero_cart(ymal_fpg, payload, default_reco):
    """Test whether ZERO cart input returns default recommendation"""
    payload["items"] = []
    out = ymal_fpg.predict(payload)
    assert out == default_reco


def test_predict(ymal_fpg, payload, default_reco):
    """Test whether a correct payload returns back a non default response"""
    out = ymal_fpg.predict(payload)
    assert isinstance(out, dict)
    assert out != default_reco


def test_predict_rank(ymal_fpg, payload):
    """Verify whether the recommended items are ranked properly"""
    out = ymal_fpg.predict(payload)
    count_of_recos = len(out["items"])
    rank_list = list(map(lambda item: int(item["rank"]), out["items"]))
    rank_list.sort()
    assert len(rank_list) == count_of_recos
    assert list(range(count_of_recos)) == rank_list


def test_arrange_recommendations_less_than_min(ymal_fpg, fetched_recos_formatted):
    """Test whether we get default response when the available recommended items are less than the minimum required count"""
    with pytest.raises(MinRecosNotMetException) as exc:
        ymal_fpg.arrange_recommendations(fetched_recos_formatted[:3], 5)
    assert "less than default minimum" in str(exc.value)


def test_arrange_recommendations_max(ymal_fpg, fetched_recos_formatted):
    """Test whether the max attribute of payload is properly used for final filtering of recommendations"""
    max_recommendations = 5
    out = ymal_fpg.arrange_recommendations(fetched_recos_formatted, max_recommendations)
    assert len(out) == max_recommendations


def test_arrange_recommendations_attributes(ymal_fpg, fetched_recos_formatted):
    """Test whether the response has additional keys like rank and type"""
    max_recommendations = 3
    out = ymal_fpg.arrange_recommendations(fetched_recos_formatted, max_recommendations)
    output_items_keys = out[0].keys()
    assert "rank" in output_items_keys
    assert "type" in output_items_keys
