import pytest
import logging

from app.utils.exceptions import DataException, DataParseException

logger = logging.getLogger(__name__)


def test_get_ymal_fpg_recos(fpg_recommendations_manager, payload: dict, fetched_recos_formatted: list):
    """Test the flow of get_ymal_fpg_recos and compare with the mock output"""
    product_basket: list = [item.get("productNumber") for item in payload.get("items")]
    out = fpg_recommendations_manager.get_ymal_fpg_recos(product_basket=product_basket)

    assert fetched_recos_formatted == out


def test_process_basket_items_fpg(fpg_recommendations_manager, payload: dict):
    """Test whether the items in basket is formatted and delimited with |(default)"""
    product_basket: list = [item.get("productNumber") for item in payload.get("items")]
    out = fpg_recommendations_manager.process_basket_items_fpg(product_basket=product_basket)
    logger.info(out)
    assert out == "407|439"


def test_process_basket_items_fpg_comma(fpg_recommendations_manager, payload: dict):
    """Test whether the items in basket is formatted and delimited with supplied delimiter"""
    product_basket: list = [item.get("productNumber") for item in payload.get("items")]
    out = fpg_recommendations_manager.process_basket_items_fpg(product_basket=product_basket, delimiter=",")
    logger.info(out)
    assert out == "407,439"


def test_format_fpg_recommendations_non_json(fpg_recommendations_manager):
    """Negative test case for wrong type of input(wrong json format)"""
    with pytest.raises(DataParseException) as exc:
        out = fpg_recommendations_manager.format_fpg_recommendations("wrong value")
    assert "Unable to parse" in str(exc.value)


def test_format_fpg_recommendations_null_to_none(fpg_recommendations_manager, fetched_recos_raw):
    """Verify whether the null values are properly mapped to pythonic None object"""
    out = fpg_recommendations_manager.format_fpg_recommendations(fetched_recos_raw[0][0])
    logger.info(out)
    assert out[1].get("productNumber") is None


def test_format_fpg_recommendations_keys(fpg_recommendations_manager, fetched_recos_raw):
    """Verify whether the method is formatting the recommendations and all the required keys are present in the output"""
    out = fpg_recommendations_manager.format_fpg_recommendations(fetched_recos_raw[0][0])
    assert set(out[0].keys()) == {"productNumber", "rank", "sizeCode", "name"}


def test_format_fpg_recommendations_missing_attributes(fpg_recommendations_manager, fetched_recos_raw_missing_args):
    """Negative test case for wrong input, wherein the database recommendations does not have some attributes"""
    with pytest.raises(DataException) as exc:
        out = fpg_recommendations_manager.format_fpg_recommendations(fetched_recos_raw_missing_args[0][0])
    assert "Attributes are missing" in str(exc.value)
