from app.conf import ConfigurationManager


class TestConfiguration:

    def test_min_recos(self, config: ConfigurationManager):
        """Testing parameter fetch from config"""
        settings_dict = config.get_settings()
        assert settings_dict.ymal_fpg.DEFAULT_MIN_RECOS == 4

    def test_max_recos(self, config: ConfigurationManager):
        """Testing parameter fetch from config"""
        settings_dict = config.get_settings()
        assert settings_dict.ymal_fpg.DEFAULT_MAX_RECOS == 10
