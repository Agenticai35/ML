from app.utils.exceptions import (
    InvalidMaxValueException,
    InvalidProductNumberInPayloadException,
    InvalidStoreInPayloadException,
    InvalidStoreInPayloadException,
    InvalidUserFormatException,
    ProductDetailsMissingInPayloadException,
)
from app.ymal_fpg.payload_validator import PayloadValidator
from attrs import asdict
import pytest
import logging

logger = logging.getLogger(__name__)


def test_validate_input_parameters():
    """Check if the payload validator raises an expection in case of malformed request body"""

    payload = {}
    with pytest.raises(Exception) as exc:
        PayloadValidator(**payload)
    assert "missing 2 required positional arguments" in str(exc.value)


def test_valid_store(payload):
    """Check if store is validated"""
    store_number = int(payload.get("store"))
    payload_post_validation = asdict(PayloadValidator(**payload))
    logger.info(payload_post_validation)
    store_post_validation = payload_post_validation.get("store")
    logger.info("Debug store post_validation=%d type=%s", store_post_validation, type(store_post_validation))
    assert store_post_validation == store_number
    assert isinstance(store_post_validation, int)


def test_invalid_store(payload):
    """Check if invalid store is detected"""
    payload["store"] = "wrong"
    with pytest.raises(InvalidStoreInPayloadException) as exc:
        PayloadValidator(**payload)


def test_user_validator_negative(payload):
    """Check if user id format is validated"""
    payload["user"] = "wrong-format"
    with pytest.raises(InvalidUserFormatException) as exc:
        PayloadValidator(**payload)


def test_max_validator(payload):
    """Check if non numeric max raises exception"""
    payload["max"] = "wrong"
    with pytest.raises(InvalidMaxValueException) as exc:
        PayloadValidator(**payload)
    assert "should be a valid integer" in str(exc)


def test_max_default(payload, config):
    """Check if max is set to default when its absent in payload"""
    payload.pop("max")
    out = asdict(PayloadValidator(**payload))
    assert out["max"] == config.get_settings().DEFAULT_MAX_RECOS


def test_max_validator_negative_number(payload):
    """Check if negative max raises exception"""
    payload["max"] = "-5"
    with pytest.raises(InvalidMaxValueException) as exc:
        PayloadValidator(**payload)
    assert "should be positive" in str(exc)


def test_server_time_validator(payload):
    """Check if server time is in valid format"""
    payload["serverTime"] = "2023-02-13 2:10:00.555"
    with pytest.raises(ValueError) as exc:
        PayloadValidator(**payload)
    assert "should be a valid timestamp" in str(exc)


def test_items_list_negative(payload):
    """Check if items is a list (negative)"""
    payload["items"] = "not a list"
    with pytest.raises(TypeError) as exc:
        PayloadValidator(**payload)


def test_items_list_positive(payload):
    """Check if items is a list"""
    payload_post_validation = asdict(PayloadValidator(**payload))
    assert isinstance(payload_post_validation.get("items"), list)


def test_missing_product_number_in_items(payload):
    """Check if product number is present for all items"""
    payload["items"] = [{"productNumber": "304"}, {}]
    with pytest.raises(ProductDetailsMissingInPayloadException) as exc:
        PayloadValidator(**payload)


def test_invalid_product_number(payload):
    """Check invalid product number"""
    payload["items"] = [{"productNumber": "304"}, {"productNumber": "wrong"}]
    with pytest.raises(InvalidProductNumberInPayloadException) as exc:
        PayloadValidator(**payload)
