import pytest
import uuid
from pathlib import Path
import sys
import json

file_path = Path(__file__).resolve()
root_directory = file_path.parents[3]
sys.path.append(str(root_directory))

from app.conf import ConfigurationManager

# from app.utils.get_pgsql import RecommendationsManager
from app.ymal_fpg.recommendations_manager import RecommendationsManager
from app.ymal_fpg.inventory_manager import InventoryManager
from app.ymal_fpg.predict import Model as YMAL_FPG


@pytest.fixture(scope="class")
def config() -> ConfigurationManager:
    """Config manager object"""
    return ConfigurationManager()


@pytest.fixture()
def default_reco() -> dict:
    """Default recommendation object"""
    with open(Path(Path(__file__).parents[3], "app", "utils", "config", "default_reco.json")) as f:
        return json.load(f)


@pytest.fixture()
def payload() -> dict:
    """Input request body for testing"""
    return {
        "user": str(uuid.uuid4()),
        "store": "11329",
        "serverTime": "2023-02-13T02:10:00Z",
        "items": [{"productNumber": "407"}, {"productNumber": "439"}],
        "max": 10,
    }


@pytest.fixture()
def max_run_id() -> str:
    """Patch the run_id param required to select latest recos"""
    return "3"


@pytest.fixture()
def fetched_recos_raw() -> list:
    """Recommendations from PGSql DB"""
    return [
        (
            "[{12, 1130, Serving, Double Chocolate Brownie}, {21, null, null, null}, {6, 430, Grande, Caramel Coffee Frappuccino}, {39, 2122117, Serving, Egg White and Roasted Red Pepper Sous Vide Egg Bite}, {33, 2123269, Serving, Potato Bake}, {9, 440, Grande, Vanilla Bean Crème Frappuccino}, {10, 2122725, Grande, Mango Dragonfruit Refresher}, {28, 1033, Serving, Butter Croissant}, {31, 2122116, Serving, Bacon and Gruyere Sous Vide Egg Bite}, {13, 2121219, Serving, Bacon},{2, 2122714, Serving, Chocolate Chunk Cookie},{31, 2122116, Serving, Bacon and Gruyere Sous Vide Egg Bite},{20, 1028, Serving, Chocolate Croissant}]",
        )
    ]


@pytest.fixture()
def fetched_recos_raw_missing_args() -> list:
    """Recommendations from PGSql DB"""
    return [
        (
            "[{12, 1130}, {21, null, null, null}, {6, 430, Grande, Caramel Coffee Frappuccino}, {39, 2122117, Serving, Egg White and Roasted Red Pepper Sous Vide Egg Bite}, {33, 2123269, Serving, Potato Bake}, {9, 440, Grande, Vanilla Bean Crème Frappuccino}, {10, 2122725, Grande, Mango Dragonfruit Refresher}, {28, 1033, Serving, Butter Croissant}, {31, 2122116, Serving, Bacon and Gruyere Sous Vide Egg Bite}, {13, 2121219, Serving, Bacon},{2, 2122714, Serving, Chocolate Chunk Cookie},{31, 2122116, Serving, Bacon and Gruyere Sous Vide Egg Bite},{20, 1028, Serving, Chocolate Croissant}]",
        )
    ]


@pytest.fixture()
def fetched_recos_formatted() -> list:
    return [
        {"rank": "12", "productNumber": "1130", "sizeCode": "Serving", "name": "Double Chocolate Brownie"},
        {"rank": "21", "productNumber": None, "sizeCode": None, "name": None},
        {"rank": "6", "productNumber": "430", "sizeCode": "Grande", "name": "Caramel Coffee Frappuccino"},
        {
            "rank": "39",
            "productNumber": "2122117",
            "sizeCode": "Serving",
            "name": "Egg White and Roasted Red Pepper Sous Vide Egg Bite",
        },
        {"rank": "33", "productNumber": "2123269", "sizeCode": "Serving", "name": "Potato Bake"},
        {"rank": "9", "productNumber": "440", "sizeCode": "Grande", "name": "Vanilla Bean Crème Frappuccino"},
        {"rank": "10", "productNumber": "2122725", "sizeCode": "Grande", "name": "Mango Dragonfruit Refresher"},
        {"rank": "28", "productNumber": "1033", "sizeCode": "Serving", "name": "Butter Croissant"},
        {
            "rank": "31",
            "productNumber": "2122116",
            "sizeCode": "Serving",
            "name": "Bacon and Gruyere Sous Vide Egg Bite",
        },
        {"rank": "13", "productNumber": "2121219", "sizeCode": "Serving", "name": "Bacon"},
        {"rank": "2", "productNumber": "2122714", "sizeCode": "Serving", "name": "Chocolate Chunk Cookie"},
        {
            "rank": "31",
            "productNumber": "2122116",
            "sizeCode": "Serving",
            "name": "Bacon and Gruyere Sous Vide Egg Bite",
        },
        {"rank": "20", "productNumber": "1028", "sizeCode": "Serving", "name": "Chocolate Croissant"},
    ]


@pytest.fixture()
def inventory_data() -> dict:
    return {
        "Hot": [414, 2123744, 466, 472, 2123931, 450, 418, 2123933, 2123926],
        "Iced": [1062, 483, 2122275, 2124026, 2123936, 2123927, 468, 2123899, 422, 2123863, 2122725],
        "Packaged": [2123778, 2122702, 2123776],
        "Single": [2123299, 2121699, 2121219, 2123221, 2121742, 2121689, 2121740, 1130, 2122117, 2122714],
    }


@pytest.fixture()
def fpg_recommendations_manager(monkeypatch, config: ConfigurationManager, fetched_recos_raw: dict, max_run_id: str):
    def patched_init(self, *args, **kwargs):
        super(RecommendationsManager, self).__init__(*args, **kwargs)
        self.fpg_pgsql_handler = None
        self.config_manager = config

    def patched_fetch_recommendations_from_database(self, *args, **kwargs):
        return fetched_recos_raw

    def patched_get_max_run_id_fpg(self, *args, **kwargs):
        return max_run_id

    monkeypatch.setattr(RecommendationsManager, "__init__", patched_init)
    monkeypatch.setattr(RecommendationsManager, "get_max_run_id_fpg", patched_get_max_run_id_fpg)
    monkeypatch.setattr(
        RecommendationsManager, "fetch_recommendations_from_database", patched_fetch_recommendations_from_database
    )
    yield RecommendationsManager()


@pytest.fixture()
def fpg_inventory_manager(monkeypatch, config: ConfigurationManager, inventory_data: dict):
    def patched_init(self, *args, **kwargs):
        super(InventoryManager, self).__init__(*args, **kwargs)
        self.store_inventory = None
        self.config_manager = config

    def patched_get_inventory_details(self, *args, **kwargs):
        return inventory_data

    monkeypatch.setattr(InventoryManager, "__init__", patched_init)
    monkeypatch.setattr(InventoryManager, "get_inventory", patched_get_inventory_details)
    yield InventoryManager()


@pytest.fixture()
def ymal_fpg(
    monkeypatch,
    config: ConfigurationManager,
    fpg_inventory_manager: InventoryManager,
    fpg_recommendations_manager: RecommendationsManager,
    default_reco: dict,
):
    def patched_init(self, *args, **kwargs):
        super(YMAL_FPG, self).__init__(*args, **kwargs)
        self.fpg_inventory_manager = fpg_inventory_manager
        self.fpg_recommendations_manager = fpg_recommendations_manager
        self.config_manager = config
        self.default_recommendations = default_reco

    monkeypatch.setattr(YMAL_FPG, "__init__", patched_init)
    yield YMAL_FPG()
