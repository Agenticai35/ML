import json
import requests
import sys
from pathlib import Path
import uuid
import datetime as dt
from edap_toolkit.request_type import RequestType

# adding root path to interpreter
file_path = Path(__file__).resolve()
root_directory = file_path.parents[1]
sys.path.append(str(root_directory))

from common import BACKEND_URL
from common.generate_auth_token import generate_token, subs_key

# initializing request details
auth_token = generate_token()

# set headers
api_headers = {
    "Content-Type": "application/json",
    "Ocp-Apim-Subscription-Key": subs_key,
    "x-correlation-id": "auth_test",
    "request-type": RequestType.FUNCTIONAL_TEST.value,
}


def test_no_auth():
    """
    Testing scenario where authorization header is missing
    """
    response = requests.post(
        url=BACKEND_URL,
        headers=api_headers,
    )
    response_output = response.json()

    assert isinstance(response_output, dict)
    assert response_output["status"] == "Auth failure"
    assert (
        response_output["result"]
        == "Please provide authorization header in the format : 'Bearer <token>'"
    )
    assert response.status_code == 401


def test_invalid_token():
    """
    Testing invalid auth token scenario
    """
    test_headers = {**api_headers, "Authorization": "Bearer dummy"}
    response = requests.post(
        url=BACKEND_URL,
        headers=test_headers,
    )
    response_output = response.json()

    assert isinstance(response_output, dict)
    assert response_output["status"] == "Auth failure"
    assert response_output["result"] == "Token is invalid"
    assert response.status_code == 401
