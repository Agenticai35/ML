import json
import requests
import sys
from pathlib import Path
import uuid
import datetime as dt
from edap_toolkit.request_type import RequestType


# adding root path to interpreter
file_path = Path(__file__).resolve()
root_directory = file_path.parents[1]
print(root_directory)
sys.path.append(str(root_directory))

from common import BACKEND_URL
from common.generate_auth_token import generate_token, subs_key

# initializing request details
auth_token = generate_token()

# set headers
api_headers = {
    "Content-Type": "application/json",
    "Ocp-Apim-Subscription-Key": subs_key,
    "Authorization": f"Bearer {auth_token}",
    "x-correlation-id": "functionality_test",
    "request-type": RequestType.FUNCTIONAL_TEST.value,
}

random_uuid = uuid.uuid4()


class TestEndpoint:
    def test_food_reco_for_beverage_item_in_cart(
        self,
    ):
        """
        Test to check whether food items are recommended if there is a beverage in the cart.
        Product number 407 = caffe latte when the test is written
        """
        input = {
            "user": str(random_uuid),
            "store": "11329",
            "serverTime": "2023-02-13T02:10:00Z",
            "items": [{"productNumber": "407"}],
            "max": 10,
        }

        # send request
        response = requests.post(
            url=BACKEND_URL,
            data=json.dumps(input),
            headers=api_headers,
        )
        response_output = response.json()

        response_code = response.status_code

        assert isinstance(response_output, dict)
        assert response_code == 200

        if len(response_output['items']) > 0:
            # get the formcode of the output
            form_code_list = [reco["formCode"] for reco in response_output["items"]]
            unique_form_codes = list(set(form_code_list))
            assert len(unique_form_codes) == 1
            assert unique_form_codes[0] == "Single"

    def test_beverage_reco_for_food_item_in_cart(
        self,
    ):
        """
        Test to check whether beverage are recommended if there is a food item in the cart.
        Product number 311 = glazed donut when the test was written.
        """
        input = {
            "user": str(random_uuid),
            "store": "11329",
            "serverTime": "2023-02-13T02:10:00Z",
            "items": [{"productNumber": "311"}],
            "max": 10,
        }

        # send request
        response = requests.post(
            url=BACKEND_URL,
            data=json.dumps(input),
            headers=api_headers,
        )
        response_output = response.json()

        response_code = response.status_code

        assert isinstance(response_output, dict)
        assert response_code == 200

        if len(response_output['items']) > 0: 
            # get the formcode of the output
            form_code_list = [reco["formCode"] for reco in response_output["items"]]
            unique_form_codes = list(set(form_code_list))

            # If the default response is returned it has more than one form codes.
            # Recommender output should contain only single form code for current implementation.
            # Iced is used for beverages and Single is used for food.
            assert len(unique_form_codes) == 1
            assert unique_form_codes[0] == "Iced"

    def test_recommendations_based_on_first_item(
        self,
    ):
        """
        Test to check complimentary recommendations are returned based on first item in the cart.
        Product number 311 = glazed donut when the test was written.
        The result should be beverages since the first item in the cart is food item.
        Although the second product is beverage.
        """
        input = {
            "user": str(random_uuid),
            "store": "11329",
            "serverTime": "2023-02-13T02:10:00Z",
            "items": [{"productNumber": "311"}, {"productNumber": "407"}],
            "max": 10,
        }

        # send request
        response = requests.post(
            url=BACKEND_URL,
            data=json.dumps(input),
            headers=api_headers,
        )
        response_output = response.json()

        response_code = response.status_code

        assert isinstance(response_output, dict)
        assert response_code == 200

        if len(response_output['items']) > 0:
            # get the formcode of the output
            form_code_list = [reco["formCode"] for reco in response_output["items"]]
            unique_form_codes = list(set(form_code_list))
            assert len(unique_form_codes) == 1
            assert unique_form_codes[0] == "Iced"

    def test_no_blackout_products_in_recos(
            self,
    ):
        """
        test to verify no blackout products are included in reco items
        """
        input = {
            "user": str(random_uuid),
            "store": "11329",
            "serverTime": "2023-02-13T02:10:00Z",
            "items": [{"productNumber": "311"}, {"productNumber": "407"}],
            "max": 10,
        }

        # send request
        response = requests.post(
            url=BACKEND_URL,
            data=json.dumps(input),
            headers=api_headers,
        )
        response_output = response.json()

        response_code = response.status_code

        assert isinstance(response_output, dict)
        assert response_code == 200

        if len(response_output['items']) > 0:
            # get the formcode of the output
            productNumber_list = [reco["productNumber"] for reco in response_output["items"]]
            blackout_products_list = [747, 2123299, 2121688, 873068654, 873068655]
            # as of 2024-05-06 we can't access settings.toml, so for now hard coding list of blacklist products here in the test case
            # list comp to compare each productNumber NOT IN list of blackout products
            recos_blklst_intersection = set(productNumber_list).intersection(set(blackout_products_list))

            assert len(recos_blklst_intersection) == 0
