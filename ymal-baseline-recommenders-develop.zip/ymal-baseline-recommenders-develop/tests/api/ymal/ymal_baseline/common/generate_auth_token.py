import sys
from pathlib import Path

# get root directory
root_directory = Path(__file__).resolve().parent
sys.path.append(root_directory)

from common import KEYVAULT_NAME

# import AIR-Utils
from edap_keyvault.key_vault import KeyVault
from edap_auth.client_application import ConfidentialApplication


# create key vault client
kv_client = KeyVault(KEYVAULT_NAME)

# fetch secrets
authority = kv_client.get_secret("token-authority")
client_id = kv_client.get_secret("air-ymal-admin-client-app-id")
scope = kv_client.get_secret("air-ymal-admin-client-scope").split(",")
secret = kv_client.get_secret("air-ymal-admin-client-key")
subs_key = kv_client.get_secret("apim-subscription-key")


# token generation function
def generate_token() -> str:
    """
    Generates bearer token based on the admin SPN
    Returns
    -------
    str
        Bearer token generated
    """

    # Create authentication application instance
    auth_app_instance = ConfidentialApplication(
        client_id,
        authority=authority,
        client_credential=secret,
    )

    return auth_app_instance.acquire_token(scope)
