import json
import requests
import sys
import uuid
from pathlib import Path
from edap_toolkit.request_type import RequestType

# adding root path to interpreter
file_path = Path(__file__).resolve()
root_directory = file_path.parents[1]
sys.path.append(str(root_directory))

from common import BACKEND_URL
from common.generate_auth_token import generate_token, subs_key

# initializing request details
auth_token = generate_token()

# set headers
api_headers = {
    "Content-Type": "application/json",
    "Ocp-Apim-Subscription-Key": subs_key,
    "Authorization": f"Bearer {auth_token}",
    "x-correlation-id": "bad_reqest_test",
    "request-type": RequestType.FUNCTIONAL_TEST.value,
}

random_uuid = str(uuid.uuid4())

def test_no_body():
    """
    Testing no request body passed scenario
    """
    response = requests.post(
        url=BACKEND_URL,
        headers=api_headers,
    )
    response_output = response.json()

    assert response_output == "Bad request: input should be a valid json"
    assert response.status_code == 400


def test_empty_body():
    """
    Testing empty input dict scenario
    """
    input = {}
    response = requests.post(
        url=BACKEND_URL,
        data=json.dumps(input),
        headers=api_headers,
    )
    response_output = response.json()

    assert "missing 2 required positional arguments" in response_output
    assert response.status_code == 400


def test_uuid_check():
    """
    Testing Unique Customer identifier is uuid or not
    """
    input = {
        "user": "08-82E4-CF45",
        "store": "11329",
        "serverTime": "2023-02-13T02:10:00Z",
        "items": [{"productNumber": "480"}],
        "max": 10,
    }
    response = requests.post(
        url=BACKEND_URL,
        data=json.dumps(input),
        headers=api_headers,
    )
    response_output = response.json()

    assert "User field is not a valid uuid" in response_output
    assert response.status_code == 400


def test_store_check():
    """
    Testing store number is a integer.
    """
    input = {
        "user": random_uuid,
        "store": "abc",
        "serverTime": "2023-02-13T02:10:00Z",
        "items": [{"productNumber": "480"}],
        "max": 10,
    }
    response = requests.post(
        url=BACKEND_URL,
        data=json.dumps(input),
        headers=api_headers,
    )
    response_output = response.json()

    assert "Store should be a valid integer" in response_output
    assert response.status_code == 400

    # more detailed assertions here


def test_product_check():
    """
    Testing product number in the cart is integer or not.
    """
    input = {
        "user": random_uuid,
        "store": "11329",
        "serverTime": "2023-02-13T02:10:00Z",
        "items": [{"productNumber": "abc"}],
        "max": 10,
    }
    response = requests.post(
        url=BACKEND_URL,
        data=json.dumps(input),
        headers=api_headers,
    )
    response_output = response.json()

    assert "product number should be a valid integer" in response_output
    assert response.status_code == 400

    # more detailed assertions here


def test_max_check():
    """
    Testing max, num of reco items, is integer or not.
    """
    input = {
        "user": random_uuid,
        "store": "11329",
        "serverTime": "2023-02-13T02:10:00Z",
        "items": [{"productNumber": "480"}],
        "max": "abc",
    }
    response = requests.post(
        url=BACKEND_URL,
        data=json.dumps(input),
        headers=api_headers,
    )
    response_output = response.json()

    assert "max should be a valid integer" in response_output
    assert response.status_code == 400
