import json
import requests
import sys
from pathlib import Path
import uuid
import datetime as dt
from edap_toolkit.request_type import RequestType


# adding root path to interpreter
file_path = Path(__file__).resolve()
root_directory = file_path.parents[1]
print(root_directory)
sys.path.append(str(root_directory))

from common import BACKEND_URL
from common.generate_auth_token import generate_token, subs_key

# initializing request details
auth_token = generate_token()

# set headers
api_headers = {
    "Content-Type": "application/json",
    "Ocp-Apim-Subscription-Key": subs_key,
    "Authorization": f"Bearer {auth_token}",
    "x-correlation-id": "functionality_test",
    "request-type": RequestType.FUNCTIONAL_TEST.value,
}

random_uuid = uuid.uuid4()


class TestEndpoint:

    def test_recommendations(
        self,
    ):

        input = {
            "user": str(random_uuid),
            "store": "11329",
            "serverTime": "2023-02-13T02:10:00Z",
            "items": [{"productNumber": "311"}, {"productNumber": "407"}],
            "max": 10,
        }

        # send request
        response = requests.post(
            url=BACKEND_URL,
            data=json.dumps(input),
            headers=api_headers,
        )
        response_output = response.json()

        response_code = response.status_code

        assert isinstance(response_output, dict)
        assert response_code == 200

        if len(response_output["items"]) > 0:
            # get the formcode of the output
            assert "formCode" in response_output["items"][0].keys()

    def test_zero_cart(
        self,
    ):
        input = {
            "user": str(random_uuid),
            "store": "11329",
            "serverTime": "2023-02-13T02:10:00Z",
            "items": [],
            "max": 10,
        }
        # send request
        response = requests.post(
            url=BACKEND_URL,
            data=json.dumps(input),
            headers=api_headers,
        )
        response_output = response.json()

        response_code = response.status_code

        assert isinstance(response_output, dict)
        assert response_code == 200
        assert response_output["recommendationId"] == "ffffffff-ffff-ffff-ffff-ffffffffffff"
