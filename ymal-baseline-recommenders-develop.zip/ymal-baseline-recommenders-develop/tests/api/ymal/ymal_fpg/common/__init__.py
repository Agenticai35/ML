import os
from typing import Any


# function to fetch environment variable if it's not present then it will raise Exception instead of KeyError
def get_env_variable(env_variable: str, default_value: str = None) -> Any:
    """Obtains the value of environment variable

    Parameters
    ----------
    env_variable : str
        name of the environment variable
    default_value : str, optional
        value to be used in case variable is not set, by default None

    Returns
    -------
    Any
        the value of the environment variable

    Raises
    ------
    Exception
        raises an exception if variable is not set
    """
    value = os.getenv(env_variable, default_value)
    if value is None:
        raise Exception(f"'{env_variable}' environment variable is not set. Please set and retry!")
    return value


# get environment variables
KEYVAULT_NAME = get_env_variable("KEYVAULT_NAME")
ENVIRONMENT = get_env_variable("ENVIRONMENT").lower()
LOCATION = get_env_variable("LOCATION")
STAGE = get_env_variable("STAGE").lower()
API_VERSION = get_env_variable("API_VERSION").lower()
# MODEL = get_env_variable("MODEL")


if LOCATION == "eus2":
    LOCATION = "eastus2"
elif LOCATION == "cus":
    LOCATION = "centralus"


# creating apim URL for the model
BACKEND_URL = f"https://aireservems-{ENVIRONMENT}-{LOCATION}-01.regional.azure-api.net/app/ymal/ymal-fpg/{API_VERSION}/predict/{STAGE}"
