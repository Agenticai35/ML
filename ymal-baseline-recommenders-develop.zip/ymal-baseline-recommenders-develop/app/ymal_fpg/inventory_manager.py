import logging
from app.conf import ConfigurationManager
import sys
from pathlib import Path
from app.utils.redis_cache_handler import RedisCache
from app.utils import duration, LogLevel, log_param


logger = logging.getLogger(__name__)


class InventoryManager:
    """
    Responsible for:
        Establishing connection to Redis for inventory check and fetch inventory for a particular store from cache
    """

    def __init__(self) -> None:

        self.config_manager = ConfigurationManager()

        self.store_inventory = RedisCache(
            tenant_id=self.config_manager.get_settings().TENANT_ID,
            keyvault_name=self.config_manager.get_settings().KEYVAULT_NAME,
            redis_connection_key=self.config_manager.get_settings().ymal_fpg.get("ddt_redis_config"),
        )

    @duration(LogLevel.debug)
    def get_inventory(self, store_number) -> dict:
        """
        Get the inventory for different form codes for the particular store number.

        Parameters
        ----------
        store_number : int
            Store number for which the recommendations are requested.
            Inventories of this store would be cross checked for product availability

        Returns
        -------
        dict
            Inventory data for the store
        """
        # TODO point back to main inventory
        # Point to inventory_testing in pg environment for testing
        dataset = f"{self.config_manager.get_settings().ymal_fpg.inventory}:{store_number}"
        key = "Items"
        result = self.store_inventory.read(dataset, key)
        return result
