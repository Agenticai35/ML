import json
import logging
from app.conf import ConfigurationManager
from app.utils.exceptions import (
    DataException,
    DataParseException,
    FetchRecommendationsException,
    MaxIdFetchException,
    RecommendationsUnavailableException,
)
from app.utils.pgsql_handler import PGSQLHandler
from edap_cache_manager import memoize, TTLCache


from app.utils import duration, LogLevel, log_param


logger = logging.getLogger(__name__)


class RecommendationsManager:
    """
    Responsible for handling the recommendations and returning back the list to the caller.

    """

    def __init__(self) -> None:

        self.config_manager = ConfigurationManager()

        self.fpg_pgsql_handler = PGSQLHandler(
            keyvault_name=self.config_manager.get_settings().KEYVAULT_NAME,
            postgres_connection_key=self.config_manager.get_settings().ymal_fpg.FPG_POSTGRES_CONNECTION_SECRET,
        )

    def get_ymal_fpg_recos(self, product_basket: list):
        """
        NOTE: YMAL-FPG v1.1 may add a table or redis cache with FPG generated
        frequent items and use those for defaults, rather than the biz provided
        defaults

        Expects a list[str] of products in the basket, these will be unpacked
        into a single string then fed into the string formatted query which
        filters the recos table down to that specific basket. Model class will
        check if there are recos, if not the default recos will be used.

        inputs:
            product_basket list[string]: list of product numbers in the basket
            represented as strings, the list will be converted table where
            product basket matches the product basket recieved from Mobile App.
        outputs:
            recos: list of dicts, each dict contains 'rank' and 'productNumber'
            of the recommendation associated with the basket that was provided

        """
        # create function to return max run_id
        max_run_id = self.get_max_run_id_fpg()

        # format product_basket list for use in query string
        sorted_delimited_products = self.process_basket_items_fpg(
            product_basket=product_basket, delimiter="|"
        )

        recommendations_from_database = self.fetch_recommendations_from_database(
            max_run_id, sorted_delimited_products
        )

        recos = recommendations_from_database[0][0]
        logger.debug("Recommendations fetched from PostgreSQL table %s", recos)

        recos = self.format_fpg_recommendations(recos)

        return recos

    @duration(LogLevel.debug)
    @memoize(cache=TTLCache(maxsize=1, ttl=300))
    def get_max_run_id_fpg(self):
        """
        This function returns the max run_id from the YMAL-FPG recos table.
        Which is required because that table is an accumulating snapshots table
        and we always want to return the latest recos, which are only in the
        max(run_id).

        Inputs:
            None required
        Output:
            max_run_id: The max value of the run_id column
        """
        table_name = self.config_manager.get_settings().ymal_fpg.FPG_RECOS_TABLE_NAME

        fpg_max_run_id_query = f"""
        SELECT max(run_id) as run_id_max
        FROM {table_name}
        """

        try:
            run_id_max_qry = self.fpg_pgsql_handler.read(fpg_max_run_id_query)
            logger.debug("Fetch max run id result: %s", run_id_max_qry)
        except Exception as exc:
            message_description = f"DB error while fetching max run_id"
            logger.exception(" %s : %s", message_description, str(exc))
            raise MaxIdFetchException(message_description)

        try:
            run_id_max_val = run_id_max_qry.result[0][0]
        except IndexError:
            message_description = f"Max run id not available in the retrieved result"
            logger.exception(message_description)
            raise MaxIdFetchException(message_description)

        if not run_id_max_val:
            message_description = f"No data in database to compute max run_id"
            logger.exception(message_description)
            raise DataException(message_description)

        return run_id_max_val

    def process_basket_items_fpg(self, product_basket: list, delimiter="|"):
        """
        Converts a list of strings into a sorted string delimited by a character

        inputs:
            product_basket: the list of strings which represent the basket of
            items to be processed
            delimiter: the character to be used as a delimiter when converting
            the list of strings into a single string
        outputs:
            sorted_str: a string, which is composed of the items from product
            basket, which have been sorted, and are delimited by the specified
            character.
        """
        product_basket.sort()
        sorted_delimited_products = f"{delimiter}".join(product_basket)
        logger.info(
            "String sorted, Delimited(with %s) product numbers in the basket: %s",
            delimiter,
            sorted_delimited_products,
        )
        return sorted_delimited_products

    @duration(LogLevel.debug)
    def fetch_recommendations_from_database(self, run_id, sorted_delimited_products):
        # build params for query string
        query_columns = ["reco_ranked_list"]
        query_columns_str = ", ".join(query_columns)
        table_name = (
            f"{self.config_manager.get_settings().ymal_fpg.FPG_RECOS_TABLE_NAME}"
        )
        logger.info(
            "Fetching recommendations from postgres table: %s for max_run_id %s and product basket %s",
            table_name,
            run_id,
            sorted_delimited_products,
        )
        # build query string from product basket
        fpg_reco_query = f"""
            SELECT {query_columns_str}
            FROM {table_name}
            WHERE run_id = {run_id}
                AND bskt_sortedStr_mapn = '{sorted_delimited_products}'
        """

        try:
            # use initialized repo_handler to execute the query
            recos_output = self.fpg_pgsql_handler.read(fpg_reco_query)
        except Exception as exc:
            message_description = "Failed to fetch recommendations from database"
            logger.error("%s : %s", message_description, str(exc))
            raise FetchRecommendationsException(message_description)

        if len(recos_output.result) == 0:
            log_param("default_status", "RECOMMENDATIONS UNAVAILABLE FOR THE BASKET")
            logger.info(
                "Recommendations unavailable for this basket in database. Default recommendations returned."
            )
            log_param("request_status", "DEFAULT")
            raise RecommendationsUnavailableException(
                "No recommendations available for the basket. Returning default recommendations."
            )
        logger.debug(
            "Recommendations fetched from postgres for max_run_id=%s, product basket=%s : %s",
            run_id,
            sorted_delimited_products,
            recos_output.result,
        )
        return recos_output.result

    def format_fpg_recommendations(self, raw_recos) -> list:
        """
        The list recommendations are stored in PostgreSQL table in a json parsable string format.
        Each recommendation has 4 positional attributes namely rank, productNumber, sizeCode and name.
        This method formats these recommendations and converts them to python dictionary for further processing.
        The positional arguments are converted to key value pairs for better understanding.
        """
        try:
            raw_recos_list_of_string = json.loads(
                raw_recos.replace("{", '"').replace("}", '"')
            )
        except json.JSONDecodeError as exc:
            message_description = f"Unable to parse the recommendations '{raw_recos}', detailed error: {str(exc)}"
            logger.error(message_description)
            raise DataParseException(message_description)
        result = []

        val_or_null = lambda input_val: (
            input_val if (input_val.lower() != "null") else None
        )
        for reco in raw_recos_list_of_string:
            try:
                val = reco.split(",")
                recommendation_dict = {
                    "rank": val_or_null(val[0].strip()),
                    "productNumber": val_or_null(val[1].strip()),
                    "sizeCode": val_or_null(val[2].strip()),
                    "name": val_or_null(val[3].strip()),
                }
                result.append(recommendation_dict)
            except IndexError as exc:
                message_description = f"Attributes are missing: {str(exc)}"
                logger.error(message_description)
                raise DataException(message_description)

        logger.debug(
            "Recommendation list from postgres with proper keys and values %s", result
        )
        return result
