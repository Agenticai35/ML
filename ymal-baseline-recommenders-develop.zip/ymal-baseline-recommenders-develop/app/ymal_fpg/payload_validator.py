from attrs import define, field, asdict
from uuid import UUID
import logging
import datetime


from app.utils import duration, LogLevel, log_param
from app.conf import ConfigurationManager
from app.utils.exceptions import (
    InvalidMaxValueException,
    InvalidProductNumberInPayloadException,
    InvalidStoreInPayloadException,
    InvalidUserFormatException,
    ProductDetailsMissingInPayloadException,
)

config_manager = ConfigurationManager().get_settings()

logger = logging.getLogger(__name__)


@define
class PayloadValidator:
    """
    This class is responsible for returning a payload IF it's valid to be used for inference
        if the Payload isn't valid to be used for inference a ValidationError should be thrown and handled within Model.predict() for the specific model
    """

    store: int = field()
    items: list = field()
    max: int = field(default=config_manager.ymal_fpg.get("DEFAULT_MAX_RECOS"))

    # Optional fields
    user: str = field(default=None)
    serverTime: str = field(default=None)
    app: str = field(default="ymal")
    clientId: str = field(default=None)
    requestTime: str = field(default=None)
    country: str = field(default=None)
    minProductCount: int = field(default=None)
    usualItem = field(default=None)
    dfSessionId: str = field(default=None)
    context1: str = field(default=None)
    context2: str = field(default=None)
    context3: str = field(default=None)
    productsSelected: list = field(default=[])
    questionsAns: list = field(default=[])
    dfSessionState: list = field(default=[])
    externalId: str = field(default=None)
    localDateTime: str = field(default=None)
    latitude: float = field(default=None)
    longitude: float = field(default=None)
    preferences: dict = field(default={})
    context: dict = field(default={})
    currentCartItems: list = field(default=[])
    maxItemsPerCategory: int = field(default=None)
    xCorrelationId: str = field(default=None)
    xDeepbrewClient: str = field(default=None)
    sku: int = field(default=None)
    limit: int = field(default=None)

    @store.validator
    def is_int(self, _, value):
        try:
            int(value)
        except ValueError as ex:
            logger.error("Store = %s", value)
            raise InvalidStoreInPayloadException("Bad request: Store should be a valid integer.")

    @items.validator
    def all_items_valid(self, _, value):
        """
        Verify items is a list or not.
        If its a list verify whether all of the items have a valid product number value(integer)
        inputs:
            value: list type

        outputs:
            logs errors if they occur
        """
        if isinstance(value, list):
            if len(value) == 0:
                logger.warning(
                    "No items available in the cart. Will result in default recommendations. Items = %s", value
                )
            for item in value:
                product_number = item.get("productNumber")
                if product_number is not None:
                    try:
                        int(product_number)
                        item["productNumber"] = item[
                            "productNumber"
                        ].strip()  # Remove extra spaces from each product and update original payload
                    except ValueError as ex:
                        logger.error("%s : productNumber = %s", str(ex), product_number)
                        raise InvalidProductNumberInPayloadException(
                            "Bad request: product number should be a valid integer."
                        )
                else:
                    logger.error("Missing productNumber field in items list. Item list = %s", value)
                    raise ProductDetailsMissingInPayloadException(
                        "Bad request: product number missing in the cart item details."
                    )
        else:
            logger.error("Items = %s", value)
            raise TypeError("Bad request: Items should be a list.")

    @user.validator
    def is_uuid(self, _, value):
        try:
            if value is not None:
                UUID(value)
        except ValueError as ex:
            logger.error("%s : user = %s", str(ex), value)
            raise InvalidUserFormatException("Bad request: User field is not a valid uuid.")

    @max.validator
    def is_positive_integer(self, _, value):
        if value:
            try:
                value = int(value)
            except ValueError:
                raise InvalidMaxValueException("Bad request: max should be a valid integer.")

            if value < 0:
                logger.error(
                    "Max recommendations should be positive. Obtained value of max items = %s",
                    value,
                )
                raise InvalidMaxValueException(
                    f"Bad request: Max recommendations should be positive. Obtained value of max items = {value}"
                )

    @serverTime.validator
    def valid_timestamp_format(self, _, value):
        try:
            if value:
                # Slicing the microseconds part of timestamp if present.
                if len(value.split(".")) > 1:
                    value = f"{value.split('.')[0]}Z"
                element = datetime.datetime.strptime(value, "%Y-%m-%dT%H:%M:%SZ")
                timestamp = datetime.datetime.timestamp(element)
        except ValueError as ex:
            logger.error(
                "ServerTime should be a valid timestamp of format YYYY-MM-DDThh:mm:ss.fffffffZ:, Obtained value = %s",
                value,
            )
            raise ValueError(
                f"ServerTime should be a valid timestamp of format YYYY-MM-DDThh:mm:ss.fffffffZ, Obtained value = {value}, {str(ex)}"
            )

    def __attrs_post_init__(self):
        self.store = int(self.store)
        if self.max:
            self.max = int(self.max)

        log_param("store_number", self.store)
        log_param("server_timestamp", self.serverTime)
        log_param("max_recos", self.max)
        log_param("cart_items", self.items)
