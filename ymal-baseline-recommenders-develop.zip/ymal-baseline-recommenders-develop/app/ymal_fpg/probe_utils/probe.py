import sys
import uuid
import logging

# Appending sys path
sys.path.append("./")

from app.utils.probe.send_request import send_request
from app.utils.probe import config_manager

logger = logging.getLogger(__name__)


input_data = {
    "user": str(uuid.uuid4()),
    "store": "2288",
    "serverTime": "2023-02-13T21:10:00Z",
    "items": [{"productNumber": "1040"}],
    "max": 10,
}

url = config_manager.ymal_fpg.URL.format(API_VERSION=config_manager.API_VERSION, STAGE=config_manager.STAGE)
# call the predict function with the model_input
output = send_request(input_data, url)

# Assertions to check the structure of the output
assert isinstance(output, dict)
# assert len(output["items"]) == 10

logger.info("Liveness probe execution successful.")
