import json
import logging
from pathlib import Path
import sys
import uuid

from app.utils.exceptions import MinRecosNotMetException

root_directory = Path(__file__).resolve().parents[2]
sys.path.append(str(root_directory))

from app.conf import ConfigurationManager


from app.utils import duration, LogLevel, log_param, mask_value
from app.utils.filter_inventory import FilterInventory


from app.ymal_fpg.inventory_manager import InventoryManager


from app.ymal_fpg.recommendations_manager import RecommendationsManager
from app.ymal_fpg.payload_validator import asdict, PayloadValidator
from edap_exceptions.exceptions import ValidationError

logger = logging.getLogger(__name__)


class Model:
    def __init__(self):
        self.config_manager = ConfigurationManager()

        # Create an instance of InventoryManager class which fetches inventory details from the inventory database
        self.fpg_inventory_manager = InventoryManager()
        # Create an instance of RecommendationsManager class which contains methods to fetch and process recommendations loaded into database.
        self.fpg_recommendations_manager = RecommendationsManager()

        # Get default recos from config folder
        with open(Path(Path(__file__).parent.parent, "utils", "config", "default_reco.json")) as file:
            self.default_recommendations = json.load(file)

    def arrange_recommendations(self, recommendations, max_recommendations):
        """
        The final recommendations are sorted based on their rank and reranked from 0.
        If the recommendations are less than min recos then, then default recommendations are returned.
        Else the required number of recommendations are returned (<=max recommendations)
        """

        logger.debug("Recommendations before filtering : %s", recommendations)
        if len(recommendations) < self.config_manager.get_settings().ymal_fpg.DEFAULT_MIN_RECOS:
            logger.info("Minimum number of recommendation items not met.")
            log_param("default_status", "MIN RECOS NOT MET")
            log_param("request_status", "DEFAULT")
            message_description = "The available recommendations are less than default minimum recommendation items."
            raise MinRecosNotMetException(message_description)
        else:

            sorted_recos = sorted(recommendations, key=lambda recommendation: int(recommendation["rank"]))

            sorted_filtered_recommendations = sorted_recos[:max_recommendations]

            fpg_variant_name = self.config_manager.get_settings().ymal_fpg.FPG_VARIANT_NAME
            for item_index in range(0, len(sorted_filtered_recommendations)):
                sorted_filtered_recommendations[item_index]["rank"] = item_index
                sorted_filtered_recommendations[item_index]["type"] = fpg_variant_name
            logger.debug("Recommendations (sorted by rank, filtered, formatted): %s", sorted_filtered_recommendations)
            return sorted_filtered_recommendations

    @duration(LogLevel.info)
    def predict(self, payload: dict) -> dict:
        """
        1. Receive & validate payload
        2. Fetch Recommendations from database
        3. Fetch Inventory from Redis
        4. Filter Recommendations by Inventory
        5. Return the reranked final recommendations
        6. Return default recommendations in case of any issues

        Parameters
        ----------
        payload : dict
            Input to the api.

        Returns
        -------
        dict
            Ranked available recommendations with a recommendationId.

        Raises
        ------
        ValidationError
            In case of bad input.
        """
        payload_without_user = payload.copy()
        user = payload.get("user", None)
        if user is not None and len(user.strip()) != 0:
            payload_without_user["user"] = mask_value(user) #"****"
        logger.info("Request body", extra={"app_param": {"input": payload_without_user}, "sink": ["file"]})

        """ 1) Validate Payload
        Responsible for:
            Extracting & validating all required elements from payload
        
        """
        try:
            payload = asdict(PayloadValidator(**payload))
        except Exception as exc:
            logger.error("Payload validation failed %s", str(exc))
            raise ValidationError(str(exc))

        store_number = payload.get("store")
        max_recommendations = payload.get("max")
        # Extract all item's productNumber from the payload
        product_basket: list = [item.get("productNumber") for item in payload.get("items")]

        # Return default recommendation for ZERO CART
        if len(product_basket) > 0:
            log_param("product_numbers_for_recos", product_basket)
        else:
            log_param("default_status", "ZERO CART REQUEST")
            logger.info("Zero cart recommendations. Default recommendations returned.")
            log_param("request_status", "DEFAULT")
            recommendations = self.default_recommendations
            log_param("recos_items", recommendations["items"])
            log_param("recos_count", len(recommendations["items"]))
            logger.info("Response", extra={"app_param": {"output": recommendations}, "sink": ["file"]})
            return recommendations

        try:
            """2) Fetch Recommendations
            Responsible for:
                Returning precomputed recommendations from a PostgreSQL database
                for YMAL-FPG: match basket against pre-computed recos
                TODO/TBD  Filter out MAPNs which aren't mapped to Product_Detail . SellableItemSupplyItemNumber?
                If no match on basket, get default_recos
            """
            precomputed_recommendations = self.fpg_recommendations_manager.get_ymal_fpg_recos(product_basket)
            logger.info("Recommendations: %s %s", precomputed_recommendations, type(precomputed_recommendations))

            """ 3) Fetch inventory of the required store
            Responsible for:
                Getting inventory data from Redis datasets
            """

            store_inventory = self.fpg_inventory_manager.get_inventory(store_number=store_number)

            """ 4) Filter recos by available inventory
            Responsible for:
                Returning intersection of Recommendation & available store inventory
            """
            # intersect recos with available inventory
            available_products = FilterInventory.filter_inventory_no_form_code(
                rec_products=precomputed_recommendations, inventory=store_inventory
            )

            """ 5) Send Recos to Mobile App
            check whether number of recos is above minimum
            if yes then sort, trim and rank recos; then return recos
            if no then return default recos
            """

            arranged_recommendations = self.arrange_recommendations(available_products, max_recommendations)
            log_param("recos_items", arranged_recommendations)
            result = {"recommendationId": str(uuid.uuid4()), "items": arranged_recommendations}
            log_param("recos_count", len(result["items"]))
            log_param("request_status", "SUCCESS")
            logger.info("Response", extra={"app_param": {"output": result}, "sink": ["file"]})
            return result

        except Exception as exc:
            """
            Return default recommendations in case of any exception apart from payload issues.
            """
            logger.exception("Exception occurred %s. Default recommendations returned.", str(exc))
            log_param("request_status", "DEFAULT")
            recommendations = self.default_recommendations
            log_param("recos_items", recommendations["items"])
            log_param("recos_count", len(recommendations["items"]))
            logger.info("Response", extra={"app_param": {"output": recommendations}, "sink": ["file"]})
            return recommendations
