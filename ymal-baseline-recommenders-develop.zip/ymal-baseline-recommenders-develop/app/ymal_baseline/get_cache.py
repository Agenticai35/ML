import json
import logging
from app.ymal_baseline.config import ConfigurationManager
import sys
from enum import Enum
from pathlib import Path
# from app.ymal_baseline import log_param
# from app.ymal_baseline import duration, LogLevel
from app.utils import duration, LogLevel, log_param
from app.utils.redis_cache_handler import RedisCache

root_directory = Path(__file__).resolve().parents[1]
sys.path.append(str(root_directory))

from edap_cache_manager import memoize, TTLCache

from edap_repo.auth.keyvault import AzureKeyVault
from edap_repo.factory.repo_factory import RepoFactory, RepoType
from edap_repo.cache.dal import CacheQueryObject


logger = logging.getLogger(__name__)


class ProductCategory(Enum):
    FOOD = "Food"
    BEVERAGE = "Beverage"
    COFFEE = "Coffee"


class Cache:
    def __init__(self) -> None:
        self.config_manager = ConfigurationManager().get_settings()
        self.ddt_redis_cache = RedisCache(
            self.config_manager.TENANT_ID,
            self.config_manager.KEYVAULT_NAME,
            self.config_manager.ymal_baseline.DDT_REDIS_CONFIG,
        )
        logger.debug("DDT repo handler created")

        # Using the same connection details as getrecs since they use the same redis instance
        self.ymal_redis_cache = self.getrecs_redis_cache = RedisCache(
            self.config_manager.TENANT_ID,
            self.config_manager.KEYVAULT_NAME,
            self.config_manager.ymal_baseline.GETRECS_REDIS_CONFIG,
        )
        logger.debug("Getrecs repo handler created")

        # Populating cache on startup wrt product details and simple random cache
        self.set_product_category_mapping()
        self.set_simple_random_sample_data()

    @duration(LogLevel.debug)
    @memoize(cache=TTLCache(maxsize=1000, ttl=180))
    def get_inventory_details(self, store_number: int) -> dict:
        """
        Get the inventory for different form codes for the particular store number.

        Parameters
        ----------
        store_number : int
            Store number for which the recommendations are requested.

        Returns
        -------
        dict
            Inventory data for the store
        """

        try:
            inventory_result = self.ddt_redis_cache.read(
                dataset=f"{self.config_manager.ymal_baseline.inventory}:{store_number}",
                key="Items",
            )
        except Exception as e:
            message_description = f"Failed to read IMS cache from redis : {str(e)}"
            logger.exception(message_description)
            raise Exception(message_description)

        if not inventory_result:
            log_param("default_status", "IMS CACHE ERROR")
            logger.exception(
                "No data found for dataset and key %s",
                f"{self.config_manager.ymal_baseline.inventory}:{store_number}",
            )
            raise Exception(
                f"No data found for dataset and key {self.config_manager.ymal_baseline.inventory}:{store_number}"
            )
        return inventory_result

    @duration(LogLevel.debug)
    @memoize(cache=TTLCache(maxsize=1, ttl=86400))
    def set_product_category_mapping(self) -> dict:
        try:
            product_details_result = self.getrecs_redis_cache.read(
                dataset=self.config_manager.ymal_baseline.product_details,
                key="Values",
            )

        except Exception as e:
            message_description = f"Failed to read Product Details : {str(e)}"
            logger.exception(message_description)
            raise Exception(message_description)

        if product_details_result:
            product_category_dict = {}
            for sku_value in product_details_result.keys():
                product_category_dict[
                    product_details_result[sku_value]["ProductNumber"]
                ] = product_details_result[sku_value]["ProductDescription"]
            return product_category_dict
        else:
            log_param("default_status", "PRODUCT DETAILS CACHE ERROR")
            logger.exception(
                "No data found for dataset and key %s",
                self.config_manager.ymal_baseline.product_details,
            )
            raise Exception(
                f"No data found for dataset and key {self.config_manager.ymal_baseline.product_details}"
            )

    @duration(LogLevel.debug)
    @memoize(cache=TTLCache(maxsize=2, ttl=21600))
    def set_simple_random_sample_data(self):
        output = {}
        srs_beverage_query = CacheQueryObject(
            command="hget",
            dataset=self.config_manager.ymal_baseline.simple_random_sample_beverage_dataset,
            key="Values",
        )
        srs_food_query = CacheQueryObject(
            command="hget",
            dataset=self.config_manager.ymal_baseline.simple_random_sample_food_dataset,
            key="Values",
        )
        result = self.ymal_redis_cache.redis_handler.batch_transactions(
            [srs_beverage_query, srs_food_query]
        )
        try:
            output[ProductCategory.BEVERAGE.value] = json.loads(result[0])
        except json.JSONDecodeError as ex:
            log_param("default_status", "SIMPLE RANDOM CACHE ERROR")
            logger.exception(
                "No data found for dataset and key %s", srs_beverage_query.as_dict()
            )
            raise Exception(
                f"No data found for dataset and key {srs_beverage_query.as_dict()}"
            )

        try:
            output[ProductCategory.FOOD.value] = json.loads(result[1])
        except json.JSONDecodeError as ex:
            log_param("default_status", "SIMPLE RANDOM CACHE ERROR")
            logger.exception(
                "No data found for dataset and key %s", srs_food_query.as_dict()
            )
            raise Exception(
                f"No data found for dataset and key {srs_food_query.as_dict()}"
            )
        return output

    @duration(LogLevel.debug)
    def get_simple_random_recs(self, product_category: str) -> dict:
        """
        Get the complimentary recommendations for the item in cart.

        Parameters
        ----------
        product_category : str
            Category of the product in the cart.

        Returns
        -------
        dict
            Complimentary recommendations dictionary.
        """
        random_sample_sample_result = self.set_simple_random_sample_data()
        if product_category == ProductCategory.FOOD.value:
            logger.debug("Food item in the cart, recommending beverages.")
            key = ProductCategory.BEVERAGE.value
        elif (
            product_category == ProductCategory.BEVERAGE.value
            or product_category == ProductCategory.COFFEE.value
        ):
            logger.debug("Beverage item in the cart, recommending food items")
            key = ProductCategory.FOOD.value
        else:
            log_param("default_status", "UNSUPPORTED PRODUCT CATEGORY")
            logger.exception(
                "Invalid product category. Obtained category: %s", product_category
            )
            raise Exception(
                "Error while fetching recommendations, invalid product category."
            )

        log_param("recommended_category", key)
        return random_sample_sample_result[key]

    @duration(LogLevel.debug)
    def get_cache(self, store_number: int, product_number: int) -> dict:
        """
        Method to read data from redis from different datasets based on logic.

        Parameters
        ----------
        store_number : int
            Store numbe for which the recommendation is requested.
        product_number : int
            Product number in the cart.

        Returns
        -------
        dict
            inventory and variant recommendations retrieved from redis.

        Raises
        ------
        Exception
            In case of any errors, respective message is raised.

        """
        cache_results = {}
        try:
            product_category = self.set_product_category_mapping()[product_number]
        except KeyError as ex:
            logger.exception(
                "Details wrt product number %s not available in the product details cache",
                product_number,
            )
            log_param("default_status", "PRODUCT CATEGORY DETAILS MISSING")
            raise

        log_param("product_category", product_category)
        logger.debug(
            "Product category obtained for product number %s = %s",
            product_number,
            product_category,
        )
        cache_results["inventory"] = self.get_inventory_details(store_number)
        cache_results["simple_random_sample_recs"] = self.get_simple_random_recs(
            product_category
        )
        logger.debug("Cache read from redis successful.")
        return cache_results
