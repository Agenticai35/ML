import logging
import sys
import json
import uuid
import random
from pathlib import Path

root_directory = Path(__file__).resolve().parents[2]
sys.path.append(str(root_directory))

from app.ymal_baseline.config import ConfigurationManager
from app.utils.filter_inventory import FilterInventory
# from app.ymal_baseline import duration, LogLevel, log_param
from app.utils import duration, LogLevel, log_param
from app.ymal_baseline.get_cache import Cache
from app.ymal_baseline.input_validator import asdict, PayloadValidator
from edap_exceptions.exceptions import ValidationError


logger = logging.getLogger(__name__)
file_logger = logging.getLogger("file_logger")


class Model:
    def __init__(self):
        self.config_manager = ConfigurationManager()

        # Create an instance of Cache class which contains the function to read data from redis
        self.cache_object = Cache()

        with open(Path(Path(__file__).parent, "config", "default_reco.json")) as f:
            self.default_recommendations = json.load(f)

    @duration(LogLevel.debug)
    def randomize_recommendations(self, recommendations: dict, max_recs: int) -> dict:
        """
        Ranks the recommendations based on randRanking.

        Parameters
        ----------
        recommendations : dict
        Recommendations obtained post inventory check.


        Returns
        -------
        dict
            Ordered recommendations.
        """

        if len(recommendations) < self.config_manager.get_settings().ymal_baseline.DEFAULT_MIN_RECOS:
            logger.info("Minimum number of reco items not met.")
            log_param("default_status", "MIN RECOS NOT MET")
            log_param("request_status", "DEFAULT")
            # If less than min_recos available, set recommendations to empty list
            # this will result in no recos being provided to app
            recommendations = list()
        else:
            if len(recommendations) > max_recs:
                recommendations = random.sample(recommendations, max_recs)
            else:
                random.shuffle(recommendations)

            initial_rank = 0
            for rec in recommendations:
                del rec["randRanking"]
                del rec["productTypeName"]
                rec["rank"] = initial_rank
                initial_rank += 1

            log_param("request_status", "SUCCESS")

        log_param("recos_items", recommendations)
        result = {"recommendationId": str(uuid.uuid4()), "items": recommendations}

        log_param("recos_count", len(result["items"]))
        logger.info("Response", extra={"app_param": {"output": result}, "sink": ["file"]})
        return result

    @duration(LogLevel.debug)
    def predict(self, payload: dict) -> dict:
        """
        Gets the recommendations based on input product and variant.
        Checks the inventory for availability and returns ranked recommendations.

        Parameters
        ----------
        payload : dict
            Input to the api.

        Returns
        -------
        dict
            Ranked available recommendations with a recommendationId.

        Raises
        ------
        ValidationError
            In case of bad input.
        """
        logger.info("Request body", extra={"app_param": {"input": payload}, "sink": ["file"]})

        try:
            payload = asdict(PayloadValidator(**payload))
        except Exception as ex:
            raise ValidationError(str(ex))

        # Obtain the required fields from the payload
        store_number = payload.get("store")
        max_recommendations = payload.get("max")
        try:
            product_number = payload.get("items")[0].get("productNumber")
            log_param("product_number_for_recos", product_number)
        except IndexError:
            log_param("default_status", "ZERO CART REQUEST")
            logger.info("Zero cart recommendations. Default recommendations returned.")
            log_param("request_status", "DEFAULT")
            recommendations = self.default_recommendations
            log_param("recos_items", recommendations["items"])
            log_param("recos_count", len(recommendations["items"]))
            logger.info("Response", extra={"app_param": {"output": recommendations}, "sink": ["file"]})
            return recommendations

        try:
            # Function call to read cached data from redis
            cache_results = self.cache_object.get_cache(store_number, product_number)

            # Perform an IMS check on the obtained products
            # For the store_number in input we will iterate through form codes and fetch the avaiable products.
            available_recommendations = FilterInventory.filter_inventory(
                cache_results["simple_random_sample_recs"], 
                cache_results["inventory"]
            )

            result = self.randomize_recommendations(
                available_recommendations, 
                max_recommendations
            )

        except Exception as exc:
            logger.exception(
                "Exception occurred %s. Default recommendations returned.", str(exc)
            )
            log_param("request_status", "DEFAULT")
            recommendations = self.default_recommendations
            log_param("recos_items", recommendations["items"])
            log_param("recos_count", len(recommendations["items"]))
            logger.info("Response", extra={"app_param": {"output": recommendations}, "sink": ["file"]})
            return recommendations

        return result
