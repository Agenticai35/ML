import yaml
import logging
from typing import Any
import logging.config
from pathlib import Path
import time
from functools import wraps
from typing import Callable
from edap_logging.filters import LogLevel

logging_config_path = Path(Path(__file__).parent, "config", "logger_config.yaml")

# Setting logger Configuration
with open(logging_config_path, "r") as f:
    logging_config_dict = yaml.safe_load(f)
logging.config.dictConfig(logging_config_dict)

logger = logging.getLogger()

