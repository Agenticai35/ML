from attrs import define, field, asdict
from uuid import UUID
import logging
import datetime
# from app.ymal_baseline import log_param, mask_value
from app.utils import log_param, mask_value
from app.ymal_baseline.config import ConfigurationManager

config_manager = ConfigurationManager().get_settings()

logger = logging.getLogger(__name__)


@define
class PayloadValidator:
    user: str = field()
    store: int = field()
    items: list = field()
    serverTime: str = field()
    max: int = field(default=config_manager.ymal_baseline.get('DEFAULT_MAX_RECOS'))

    # Optional fields
    app: str = field(default="ymal")
    clientId: str = field(default=None)
    requestTime: str = field(default=None)
    country: str = field(default=None)
    minProductCount: int = field(default=None)
    usualItem = field(default=None)
    dfSessionId: str = field(default=None)
    context1: str = field(default=None)
    context2: str = field(default=None)
    context3: str = field(default=None)
    productsSelected: list = field(default=[])
    questionsAns: list = field(default=[])
    dfSessionState: list = field(default=[])
    externalId: str = field(default=None)
    localDateTime: str = field(default=None)
    latitude: float = field(default=None)
    longitude: float = field(default=None)
    preferences: dict = field(default={})
    context: dict = field(default={})
    currentCartItems: list = field(default=[])
    maxItemsPerCategory: int = field(default=None)
    xCorrelationId: str = field(default=None)
    xDeepbrewClient: str = field(default=None)
    sku: int = field(default=None)
    limit: int = field(default=None)

    @store.validator
    def is_int(self, _, value):
        try:
            int(value)
        except ValueError as ex:
            logger.error("Store = %s", value)
            raise TypeError("Bad request: Store should be a valid integer.")

    @items.validator
    def items_valid(self, _, value):
        if isinstance(value, list):
            try:
                if value[0].get("productNumber"):
                    int(value[0].get("productNumber"))
                else:
                    logger.error('Missing productNumber field in items list. Item element = %s', value)
                    raise Exception("Bad request: product number missing in the cart item details.")
            except IndexError:
                logger.warning('No items available in the cart. Items = %s', value)
            except ValueError as ex:
                logger.error("%s : productNumber = %s", str(ex), value[0].get("productNumber"))
                raise TypeError("Bad request: product number should be a valid integer.")
        else:
            logger.error("Items = %s", value)
            raise TypeError("Bad request: Items should be a list.")


    @user.validator
    def is_uuid(self, _, value):
        try:
            UUID(value)
        except ValueError as ex:
            logger.error("%s : user = %s", str(ex), value)
            raise ValueError("Bad request: User field is not a valid uuid.")

    @max.validator
    def is_greater_than_zero(self, _, value):
        if value:
            try:
                value = int(value)
            except ValueError:
                raise TypeError("Bad request: max should be a valid integer.")

            if value < 0:
                logger.error(
                    "Max recommendations should be positive. Obtained value of max items = %s",
                    value,
                )
                raise ValueError(
                    f"Bad request: Max recommendations should be positive. Obtained value of max items = {value}"
                )

    @serverTime.validator
    def check_timestamp(self, _, value):
        try:
            # Slicing the microseconds part of timestamp if present.
            if len(value.split('.')) > 1:
                value = f"{value.split('.')[0]}Z"
            element = datetime.datetime.strptime(value, "%Y-%m-%dT%H:%M:%SZ")
            timestamp = datetime.datetime.timestamp(element)
        except ValueError as ex:
            logger.error(
                "ServerTime should be a valid timestamp of format YYYY-MM-DDThh:mm:ss.fffffffZ:, Obtained value = %s",
                value,
            )
            raise ValueError(
                f"ServerTime should be a valid timestamp of format YYYY-MM-DDThh:mm:ss.fffffffZ, Obtained value = {value}"
            )

    def __attrs_post_init__(self):
        self.store = int(self.store)
        if self.max:
            self.max = int(self.max)
        else: 
            self.max = config_manager.ymal_baseline.get('DEFAULT_MAX_RECOS')
        try:
            self.items[0]['productNumber'] = int(self.items[0].get("productNumber"))
        except Exception:
            logger.debug('Zero items in the cart. Will result in default recommendations.')
            pass
        log_param('store_number', self.store)
        log_param('user_id', mask_value(self.user))
        log_param('server_timestamp', self.serverTime)
        log_param('max_recos', self.max)
        log_param('cart_items', self.items)
