#https://learn.microsoft.com/en-us/sql/connect/odbc/linux-mac/installing-the-microsoft-odbc-driver-for-sql-server?view=sql-server-ver16
echo "Installing ODBC driver"

# For installing psycopg2 gcc and libpg-dev needs to be present.
apt-get update \
&& apt-get install -y curl apt-transport-https \
&& apt-get install -y gnupg \
&& apt-get install -y gcc g++ libpq-dev \
&& curl https://packages.microsoft.com/keys/microsoft.asc | gpg --dearmor -o /usr/share/keyrings/microsoft-prod.gpg \
&& curl https://packages.microsoft.com/config/debian/12/prod.list > /etc/apt/sources.list.d/mssql-release.list \
&& apt-get update \
&& ACCEPT_EULA=Y apt-get install -y msodbcsql18 unixodbc-dev