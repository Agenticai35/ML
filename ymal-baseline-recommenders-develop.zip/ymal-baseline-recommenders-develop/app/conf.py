from dataclasses import dataclass
from pathlib import Path

from dynaconf import Dynaconf

root_directory = Path(__file__).resolve().parent.parent

settings = Dynaconf(
    warn_dynaconf_global_settings=True,
    environments=True,
    lowercase_read=True,  # case insensitive
    load_dotenv=False,
    settings_files=[f"{root_directory}/settings.toml"],
    core_loaders=["TOML"],
)


@dataclass
class ConfigurationManager:

    @staticmethod
    def get_settings() -> Dynaconf:
        return settings
