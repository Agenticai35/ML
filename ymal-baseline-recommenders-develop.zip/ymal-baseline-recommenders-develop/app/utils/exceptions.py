class YMALException(Exception):
    pass


class RedisReadException(YMALException):
    pass


class RedisDataNotFoundException(YMALException):
    pass


class PostgreSQLReadException(YMALException):
    pass


class MaxIdFetchException(YMALException):
    pass


class FetchRecommendationsException(YMALException):
    pass


class RecommendationsUnavailableException(YMALException):
    pass


class DataParseException(YMALException):
    pass


class DataException(YMALException):
    pass


class MinRecosNotMetException(YMALException):
    pass


class InvalidStoreInPayloadException(YMALException):
    pass


class InvalidProductNumberInPayloadException(YMALException):
    pass


class ProductDetailsMissingInPayloadException(YMALException):
    pass


class InvalidUserFormatException(YMALException):
    pass


class InvalidMaxValueException(YMALException):
    pass
