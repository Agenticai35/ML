import yaml
import logging
from typing import Any
import logging.config
from pathlib import Path
import time
from functools import wraps
from typing import Callable
from edap_logging.filters import LogLevel

logger = logging.getLogger()

def mask_value(value: str, mask_char="*", num_visible=4):
    """
    Mask sensitive values with a specified character, keeping a specified number of characters visible.
    """
    if num_visible >= len(value):
        return value
    visible_part = value[:num_visible]
    masked_part = mask_char * (len(value) - num_visible)
    return visible_part + masked_part

def log_param(name: str, value: Any, log_level: LogLevel = LogLevel.info, file_sink: bool = True) -> None:
    """
    Method to log parameters in uniform fashion.

    Parameters
    ----------
    name : str
        name of the parameter/metric.
    value : Any
        Value of the parameter
    log_level : LogLevel, optional
        level of the parameter based on log level, by default LogLevel.info
    """
    params = {name: value}
    description = f"{name}: {value}"
    if log_level == LogLevel.debug:
        logger.debug(description, extra=params)
    else:
        logger.info(description, extra=params)


def duration(log_level: LogLevel = None):
    def _decorator(func: Callable):
        """Duration decorator for functions"""

        @wraps(func)
        def wrapper(*args, **kwargs):
            start_time = time.time()
            result = func(*args, **kwargs)
            duration = round(time.time() - start_time, 3)
            if "log_level" not in locals() or callable(log_level) or log_level is None:
                log_param(f"{func.__name__}_time (sec)", duration, file_sink=False)
            else:
                log_param(f"{func.__name__}_time (sec)", duration, log_level=log_level, file_sink=False)
            return result

        return wrapper

    return _decorator(log_level) if callable(log_level) else _decorator
