import requests
import json
import time
import os
import sys
import logging
import logging.handlers
from edap_toolkit.request_type import RequestType

# Appending sys path
sys.path.append("./")

from app.utils.probe.generate_token import generate_token as gen_token
from app.utils.probe import config_manager

global_path = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

# Initializing logger
logger = logging.getLogger("probe_logger")
file_handler = logging.handlers.RotatingFileHandler(
    os.path.join(global_path, "probe.log"),
    maxBytes=config_manager.MAX_BYTES,
    backupCount=config_manager.BACKUP_COUNT,
)
logger.addHandler(file_handler)
logger.setLevel(logging.DEBUG)


def update_token():
    """
    Generating a new token and pickling it for reuse which lives for 55 minutes.
    Returns
    -------
    str
        Newly generated token.
    """
    token_dict = {"token": gen_token(), "token_gen_time": time.time()}
    os.environ["PROBE_TOKEN"] = json.dumps(token_dict)
    logger.info("Updating token in env var")
    return token_dict["token"]


def send_request(model_input, url):
    start_time = time.time()

    token_dict = os.environ.get("PROBE_TOKEN")
    if token_dict:
        token_dict = json.loads(token_dict)

        token = token_dict["token"]
        token_gen_time = token_dict["token_gen_time"]

        token_age = time.time() - token_gen_time
        logger.debug("Calculating token age")

        if token is None or token_age > config_manager.TOKEN_EXPIRY:
            # If age greater than 55min updating the token
            token = update_token()
            logger.info("Token is None/Expired. Generating new token.")
    else:
        # If pickle doesn't exist, creating one with token
        token = update_token()

    payload = json.dumps(model_input)

    headers = {
        "Authorization": f"Bearer {token}",
        "request-type": RequestType.LIVENESS_AUTH.value,
    }
    response = requests.request("POST", url, headers=headers, data=payload)
    if response.status_code == 401:
        token = update_token()
        response = requests.request("POST", url, headers=headers, data=payload)
    logger.debug("Total time taken --%f", time.time() - start_time)
    return response.json()
