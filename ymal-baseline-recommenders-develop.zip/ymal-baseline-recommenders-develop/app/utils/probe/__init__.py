import os
from typing import Any
from app.conf import ConfigurationManager

config_manager = ConfigurationManager().get_settings()
