import msal
import os
import base64
import sys
from pathlib import Path

# Appending sys path
sys.path.append("./")

root_directory = Path(__file__).resolve().parent
sys.path.append(root_directory)


from app.utils.probe import config_manager
from edap_keyvault.key_vault import KeyVault
from edap_auth.client_application import ConfidentialApplication

kv_client = KeyVault(config_manager.KEYVAULT_NAME)


class TokenGenError(Exception):
    """
    Exception is there is any error while generating token
    """

    pass


def generate_token():
    # get client id (app id)
    client_id = kv_client.get_secret(config_manager.CLIENT_APP_ID)
    secret = kv_client.get_secret(config_manager.CLIENT_SECRET)

    # A URL that identifies a token authority. It should be of the format ``https://login.microsoftonline.com/your_tenant``
    authority = kv_client.get_secret(config_manager.AUTHORITY)
    # creating default scope as per azure policies for the app
    scope = kv_client.get_secret(config_manager.CLIENT_SCOPE).split(",")
    # default_scope = f"api://{app_id}/.default"

    # create application
    app = ConfidentialApplication(client_id, authority=authority, client_credential=secret)
    result = None

    # Firstly, looks up a token from cache
    # Since we are looking for token for the current app, NOT for an end user,
    # notice we give account parameter as None.
    result = app.acquire_token_silent(scope, account=None)

    if not result:
        result = app.acquire_token_for_client(scopes=scope)

    if "access_token" not in result:
        raise TokenGenError(f"Error while generating token: {result}")

    return result["access_token"]
