import json
import logging

from app.utils import duration, LogLevel, log_param
from app.utils.exceptions import RedisDataNotFoundException, RedisReadException


from edap_cache_manager import memoize, TTLCache

from edap_repo.auth.keyvault import AzureKeyVault
from edap_repo.factory.repo_factory import RepoFactory, RepoType
from edap_repo.cache.dal import CacheQueryObject


logger = logging.getLogger(__name__)


class RedisCache:
    def __init__(self, tenant_id, keyvault_name, redis_connection_key) -> None:
        key_vault = AzureKeyVault(
            tenant=tenant_id,
            kv_name=keyvault_name,
        )

        # Create an instance of a handler that will be used to fetch data from redis
        factory = RepoFactory()
        self.redis_handler = factory.create(
            RepoType.REMOTE_CACHE,
            key_vault=key_vault,
            key=redis_connection_key,
        )
        logger.debug("Redis cache handler created")

    @duration(LogLevel.debug)
    @memoize(cache=TTLCache(maxsize=1000, ttl=180))
    def read(self, dataset, key) -> dict:
        """
        Read the intended redis cache to fetch data against the required dataset.
        """

        query = CacheQueryObject(dataset=dataset, key=key)

        try:
            cache_result = self.redis_handler.read(query).result

        except Exception as e:
            message_description = f"Failed to read from redis : {str(e)}"
            logger.exception(message_description)
            raise RedisReadException(message_description)

        if cache_result:
            cache_result = json.loads(cache_result)
            logger.debug("Cache result: %s", cache_result)
        else:
            log_param("default_status", "CACHE ERROR")
            message_description = f"No data found for dataset '{dataset}' and key '{key}'"
            logger.exception(message_description)
            raise RedisDataNotFoundException(message_description)
        return cache_result
