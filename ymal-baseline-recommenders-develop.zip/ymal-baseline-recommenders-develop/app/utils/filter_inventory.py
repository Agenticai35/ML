import logging
import sys
import json
from json import JSONDecodeError
from pathlib import Path


from app.utils import duration, LogLevel, log_param

logger = logging.getLogger(__name__)


class FilterInventory:
    def __init__(self):
        pass

    @staticmethod
    def filter_inventory(rec_products: dict, inventory: dict) -> list:
        """
        Checks if the product numbers and form codes in the recommendations are available in the inventory.

        Parameters
        ----------
        rec_products : dict
            Products recommended from the variant.
        inventory : dict
            The inventory data for the particular store.

        Returns
        -------
        list
            List of available recommendations.
        """

        recommendations = list()
        for product in rec_products:
            try:
                product = json.loads(product)
                product_number = int(product["productNumber"])
            except JSONDecodeError as ex:
                logger.exception("Unable to parse product details. Exception: %s", str(ex))
                raise Exception(f"Unable to parse product details. Exception: {str(ex)}")
            except ValueError as ex:
                logger.exception(
                    "Invalid value for productNumber from the recommendation products. Product number should be integer. Error: %s",
                    str(ex),
                )
                raise Exception("Invalid product number.")

            form_code = product["formCode"]
            try:
                if product_number in inventory[form_code]:
                    is_available = True
                else:
                    is_available = False
            except:
                is_available = False

            if is_available == True:
                recommendations.append(product)

        log_param("recos_count_post_inv", len(recommendations))

        return recommendations

    @staticmethod
    def filter_inventory_no_form_code(rec_products: dict, inventory: dict) -> list:
        """
        Checks if the product numbers in the recommendations are available in the inventory.
        Since form codes are not available in the recommendations, the method checks against all the form codes present.

        Parameters
        ----------
        rec_products : dict
            Products recommended from the variant.
        inventory : dict
            The inventory data for the particular store.

        Returns
        -------
        list
            List of available recommendations.
        """

        recommendations = list()

        logger.debug("Products before inventory filter: %s", set([item["productNumber"] for item in rec_products]))

        for reco_index in range(0, len(rec_products)):
            # initialize is_avail to false, if recommended product not found in inventory, then remove it from reco list
            is_available = False

            try:
                # loop through all form codes since recos don't have formCode included
                for form_code in inventory.keys():
                    if int(rec_products[reco_index]["productNumber"]) in inventory[form_code]:
                        rec_products[reco_index]["formCode"] = form_code
                        is_available = True

            except:
                is_available = False

            if is_available == True:
                recommendations.append(rec_products[reco_index])

        log_param("recos_count_post_inv", len(recommendations))
        logger.debug("Products post inventory filter: %s", set([item["productNumber"] for item in recommendations]))

        return recommendations
