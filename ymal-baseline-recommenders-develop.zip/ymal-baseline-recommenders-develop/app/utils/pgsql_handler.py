import json
import logging

from app.utils import duration, LogLevel, log_param
from app.utils.exceptions import PostgreSQLReadException


from edap_keyvault.key_vault import KeyVault
from edap_repo.factory.repo_factory import RepoFactory, RepoType
from edap_repo.api.dal import QueryResult


logger = logging.getLogger(__name__)


class PGSQLHandler:
    """
    Responsible for:
        Returning data from PostGreSQL databases

    """

    def __init__(self, keyvault_name, postgres_connection_key) -> None:
        keyvault_util = KeyVault(keyvault_name=keyvault_name)

        pgsql_conn_dict = json.loads(keyvault_util.get_secret(secret_name=postgres_connection_key))
        config = {"connection_parameters": pgsql_conn_dict}

        # Create an instance of a handler that will be used to fetch data from PGSQL
        factory = RepoFactory()

        # Create repo handler to connect with PGSQL database
        self.pgsql_handler = factory.create(RepoType.COSMOS_PGSQL, **config)

    def read(self, query) -> QueryResult:
        """
        Read data from the PostgreSQL database using the supplied query.

        Parameters
        ----------
        query : str
            Query to read data from PGSQL database

        Returns
        -------
        QueryResult
            Returns the QueryResult object with the results in the result attribute
        """
        try:
            query_result = self.pgsql_handler.read(query)
        except Exception as exc:
            message_description = "Failed to fetch data from database"
            logger.error("%s : %s", message_description, str(exc))
            raise PostgreSQLReadException(message_description)
        return query_result
