from attrs import define, field, asdict
from uuid import UUID
import logging
import datetime

from payload_validator_util.utils import log_param
from payload_validator_util.conf import ConfigurationManager
from payload_validator_util.exceptions import (
    InvalidMaxValueException,
    InvalidProductNumberInPayloadException,
    InvalidStoreInPayloadException,
    InvalidUserFormatException,
    ProductDetailsMissingInPayloadException,
)

config_manager = ConfigurationManager().get_settings()

logger = logging.getLogger(__name__)


@define
class PayloadValidator:
    """
    This class is responsible for returning a payload IF it's valid to be used for inference.
    If the payload isn't valid, a ValidationError should be thrown and handled within Model.predict().
    """

    store: int = field()
    items: list = field()
    max: int = field(default=config_manager.get("DEFAULT_MAX_RECOS"))

    # Optional fields
    user: str = field(default=None)
    serverTime: str = field(default=None)

    @store.validator
    def is_int(self, _, value):
        try:
            int(value)
        except ValueError:
            logger.error("Store = %s", value)
            raise InvalidStoreInPayloadException("Bad request: Store should be a valid integer.")

    @items.validator
    def all_items_valid(self, _, value):
        """
        Verify items is a list or not.
        If it's a list, verify whether all of the items have a valid product number value (integer).
        """
        if isinstance(value, list):
            if len(value) == 0:
                logger.warning(
                    "No items available in the cart. Will result in default recommendations. Items = %s", value
                )
            for item in value:
                product_number = item.get("productNumber")
                if product_number is not None:
                    try:
                        if isinstance(product_number, int):
                            item["productNumber"] = str(product_number)
                        else:
                            int(product_number)
                            item["productNumber"] = item["productNumber"].strip()
                    except ValueError:
                        logger.error("Invalid productNumber = %s", product_number)
                        raise InvalidProductNumberInPayloadException(
                            "Bad request: product number should be a valid integer."
                        )
                else:
                    logger.error("Missing productNumber field in items list. Item list = %s", value)
                    raise ProductDetailsMissingInPayloadException(
                        "Bad request: product number missing in the cart item details."
                    )
        else:
            logger.error("Items = %s", value)
            raise TypeError("Bad request: Items should be a list.")

    @user.validator
    def is_uuid(self, _, value):
        try:
            if value is not None:
                UUID(value)
        except ValueError:
            logger.error("Invalid user = %s", value)
            raise InvalidUserFormatException("Bad request: User field is not a valid UUID.")

    @max.validator
    def is_positive_integer(self, _, value):
        if value:
            try:
                value = int(value)
            except ValueError:
                raise InvalidMaxValueException("Bad request: max should be a valid integer.")

            if value < 0:
                logger.error("Max recommendations should be positive. Obtained value = %s", value)
                raise InvalidMaxValueException(
                    f"Bad request: Max recommendations should be positive. Obtained value = {value}"
                )

    def __attrs_post_init__(self):
        self.store = int(self.store)
        if self.max:
            self.max = int(self.max)

        log_param("store_number", self.store)
        log_param("server_timestamp", self.serverTime)
        log_param("max_recos", self.max)
        log_param("cart_items", self.items)