import logging
import time
from functools import wraps
from typing import Any, Callable
from edap_logging.filters import LogLevel

logger = logging.getLogger(__name__)

def log_param(
    name: str, value: Any, log_level: LogLevel = LogLevel.info, file_sink: bool = True
) -> None:
    """
    Method to log parameters in a uniform fashion.

    Parameters
    ----------
    name : str
        Name of the parameter/metric.
    value : Any
        Value of the parameter.
    log_level : LogLevel, optional
        Level of the parameter based on log level, by default LogLevel.info.
    file_sink : bool, optional
        Whether to log to a file sink, by default True.
    """
    params = {name: value}
    description = f"{name}: {value}"
    if log_level == LogLevel.debug:
        logger.debug(description, extra=params)
    else:
        logger.info(description, extra=params)


def duration(log_level: LogLevel = None):
    """
    Decorator to measure the execution time of a function and log it.

    Parameters
    ----------
    log_level : LogLevel, optional
        Log level for the duration, by default None.
    """
    def _decorator(func: Callable):
        @wraps(func)
        def wrapper(*args, **kwargs):
            start_time = time.time()
            result = func(*args, **kwargs)
            duration = round(time.time() - start_time, 3)
            log_param(
                f"{func.__name__}_time (sec)",
                duration,
                log_level=log_level or LogLevel.info,
                file_sink=False,
            )
            return result
        return wrapper
    return _decorator