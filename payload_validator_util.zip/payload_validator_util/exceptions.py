class YMALException(Exception):
    """
    Base exception for all YMAL-related errors.
    """
    pass


class InvalidMaxValueException(YMALException):
    """
    Exception raised when the 'max' value in the payload is invalid.
    """
    pass


class InvalidProductNumberInPayloadException(YMALException):
    """
    Exception raised when a product number in the payload is invalid.
    """
    pass


class InvalidStoreInPayloadException(YMALException):
    """
    Exception raised when the store value in the payload is invalid.
    """
    pass


class InvalidUserFormatException(YMALException):
    """
    Exception raised when the user field in the payload is not a valid UUID.
    """
    pass


class ProductDetailsMissingInPayloadException(YMALException):
    """
    Exception raised when product details are missing in the payload.
    """
    pass