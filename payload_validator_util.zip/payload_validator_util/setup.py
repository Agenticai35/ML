from setuptools import setup, find_packages

setup(
    name="payload_validator_util",
    version="1.0.0",
    description="A utility package for validating payloads and managing configurations",
    author="Your Name",
    author_email="your.email@example.com",
    packages=find_packages(),
    install_requires=[
        "dynaconf>=3.1.7",
        "attrs>=21.4.0",
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.7",
)