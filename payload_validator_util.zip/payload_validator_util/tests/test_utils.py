import pytest
import logging
from payload_validator_util.utils import log_param, duration
from edap_logging.filters import LogLevel
import time

# Mock logger for testing
class MockLogger:
    def __init__(self):
        self.logs = []

    def info(self, message, extra=None):
        self.logs.append(("info", message, extra))

    def debug(self, message, extra=None):
        self.logs.append(("debug", message, extra))

    def get_logs(self):
        return self.logs


@pytest.fixture
def mock_logger(monkeypatch):
    """
    Fixture to mock the logger for testing.
    """
    mock_logger = MockLogger()
    monkeypatch.setattr("payload_validator_util.utils.logger", mock_logger)
    return mock_logger


def test_log_param_info(mock_logger):
    """
    Test log_param with LogLevel.info.
    """
    log_param("test_param", "test_value", log_level=LogLevel.info)
    logs = mock_logger.get_logs()
    assert len(logs) == 1
    assert logs[0][0] == "info"
    assert logs[0][1] == "test_param: test_value"
    assert logs[0][2] == {"test_param": "test_value"}


def test_log_param_debug(mock_logger):
    """
    Test log_param with LogLevel.debug.
    """
    log_param("test_param", "test_value", log_level=LogLevel.debug)
    logs = mock_logger.get_logs()
    assert len(logs) == 1
    assert logs[0][0] == "debug"
    assert logs[0][1] == "test_param: test_value"
    assert logs[0][2] == {"test_param": "test_value"}


def test_duration_decorator():
    """
    Test the duration decorator.
    """
    @duration(log_level=LogLevel.info)
    def sample_function():
        time.sleep(0.1)
        return "success"

    result = sample_function()
    assert result == "success"