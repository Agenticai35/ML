import pytest
from payload_validator_util.validator import PayloadValidator
from payload_validator_util.exceptions import (
    InvalidMaxValueException,
    InvalidProductNumberInPayloadException,
    InvalidStoreInPayloadException,
    InvalidUserFormatException,
    ProductDetailsMissingInPayloadException,
)

# Test cases for PayloadValidator
class TestPayloadValidator:
    def test_valid_payload(self):
        payload = {
            "store": 123,
            "items": [{"productNumber": "456"}, {"productNumber": "789"}],
            "max": 10,
            "user": "550e8400-e29b-41d4-a716-446655440000",
            "serverTime": "2025-04-26T12:00:00Z",
        }
        validator = PayloadValidator(**payload)
        assert validator.store == 123
        assert len(validator.items) == 2
        assert validator.max == 10

    def test_invalid_store(self):
        payload = {
            "store": "invalid_store",
            "items": [{"productNumber": "456"}],
            "max": 10,
        }
        with pytest.raises(InvalidStoreInPayloadException):
            PayloadValidator(**payload)

    def test_missing_product_number(self):
        payload = {
            "store": 123,
            "items": [{}],  # Missing productNumber
            "max": 10,
        }
        with pytest.raises(ProductDetailsMissingInPayloadException):
            PayloadValidator(**payload)

    def test_invalid_product_number(self):
        payload = {
            "store": 123,
            "items": [{"productNumber": "invalid_number"}],
            "max": 10,
        }
        with pytest.raises(InvalidProductNumberInPayloadException):
            PayloadValidator(**payload)

    def test_invalid_user_uuid(self):
        payload = {
            "store": 123,
            "items": [{"productNumber": "456"}],
            "max": 10,
            "user": "invalid_uuid",
        }
        with pytest.raises(InvalidUserFormatException):
            PayloadValidator(**payload)

    def test_invalid_max_value(self):
        payload = {
            "store": 123,
            "items": [{"productNumber": "456"}],
            "max": -1,  # Invalid max value
        }
        with pytest.raises(InvalidMaxValueException):
            PayloadValidator(**payload)

    def test_empty_items_list(self):
        payload = {
            "store": 123,
            "items": [],  # Empty items list
            "max": 10,
        }
        validator = PayloadValidator(**payload)
        assert validator.store == 123
        assert len(validator.items) == 0
        assert validator.max == 10