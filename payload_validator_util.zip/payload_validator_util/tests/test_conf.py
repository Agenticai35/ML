import pytest
from dynaconf import Dynaconf
from payload_validator_util.conf import ConfigurationManager

class TestConfigurationManager:
    def test_get_settings(self):
        """
        Test that the ConfigurationManager correctly retrieves settings.
        """
        settings = ConfigurationManager.get_settings()
        assert isinstance(settings, Dynaconf), "Settings should be an instance of Dynaconf"
        assert settings.DEFAULT_MAX_RECOS == 10, "DEFAULT_MAX_RECOS should be set to 10 in settings.toml"

    def test_missing_settings_file(self, monkeypatch):
        """
        Test behavior when the settings file is missing.
        """
        # Temporarily change the settings file path to a non-existent file
        monkeypatch.setattr(
            "payload_validator_util.conf.root_directory",
            "/non/existent/path"
        )
        with pytest.raises(FileNotFoundError):
            ConfigurationManager.get_settings()